package com.nova;

import net.fabricmc.loader.api.FabricLoader;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;

/**
 * Проверка обновлений: читает текстовый файл с последней версией (одна строка, например 1.2.0).
 * Адрес задаётся в VERSION_URL. Пока там OWNER/REPO — проверка сообщает, что адрес не задан.
 */
public final class Updater {
    public static final String VERSION_URL = "https://raw.githubusercontent.com/OWNER/REPO/main/version.txt";
    public static volatile String status = "Не проверялось";

    private Updater() {}

    public static String current() {
        return FabricLoader.getInstance().getModContainer("fl1xvisuals")
                .map(c -> c.getMetadata().getVersion().getFriendlyString()).orElse("?");
    }

    public static void check() {
        if (VERSION_URL.contains("OWNER/REPO")) {
            status = "Адрес не задан";
            NovaScreen.toast("Адрес обновлений не задан в моде");
            return;
        }
        status = "Проверяю...";
        try {
            HttpClient cl = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(6)).build();
            HttpRequest rq = HttpRequest.newBuilder(URI.create(VERSION_URL)).timeout(Duration.ofSeconds(8)).GET().build();
            cl.sendAsync(rq, HttpResponse.BodyHandlers.ofString()).whenComplete((r, err) -> {
                if (err != null || r.statusCode() != 200) {
                    status = "Нет связи";
                    return;
                }
                String latest = r.body().trim();
                if (latest.isEmpty() || latest.length() > 20) { status = "Ответ не распознан"; return; }
                status = latest.equals(current()) ? "У тебя последняя версия" : "Доступна " + latest;
            });
        } catch (Exception e) {
            status = "Ошибка проверки";
        }
    }
}
