package com.nova;

import com.nova.mixin.SimpleOptionAccessor;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.LivingEntity;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import org.lwjgl.glfw.GLFW;

public class NovaClient implements ClientModInitializer {
    public static KeyBinding menuKey;
    public static KeyBinding zoomKey;

    private static Integer savedFov = null;
    private static Double savedGamma = null;
    private static double zoomCur = 1.0;

    @Override
    public void onInitializeClient() {
        NovaConfig.load();

        menuKey = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.novamenu.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_INSERT, "category.novamenu"));
        zoomKey = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.novamenu.zoom", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C, "category.novamenu"));

        ClientTickEvents.END_CLIENT_TICK.register(NovaClient::tick);
        ClientLifecycleEvents.CLIENT_STOPPING.register(c -> { restore(c); NovaConfig.save(); });
        Hud.register();

        // Кнопка NOVA на титульном экране и в меню паузы: так меню открывается и на телефоне без клавиатуры.
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (screen instanceof TitleScreen || screen instanceof GameMenuScreen) {
                Screens.getButtons(screen).add(ButtonWidget.builder(Text.literal("NOVA"),
                        b -> client.setScreen(new NovaScreen(screen))).dimensions(6, 6, 60, 20).build());
            }
        });

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.isClient && entity instanceof LivingEntity) Hud.hitAt = System.currentTimeMillis();
            return ActionResult.PASS;
        });
    }

    private static void tick(MinecraftClient c) {
        while (menuKey.wasPressed()) {
            c.setScreen(new NovaScreen(null));
        }
        if (c.player == null || c.world == null) return;

        // FOV
        var fov = c.options.getFov();
        if (NovaConfig.on("fov")) {
            if (savedFov == null) savedFov = fov.getValue();
            int want = (int) NovaConfig.num("fov.v");
            if (fov.getValue() != want) fov.setValue(want);
        } else if (savedFov != null) {
            fov.setValue(savedFov);
            savedFov = null;
        }

        // Fullbright: яркость выше обычного максимума, пишем значение напрямую
        var gamma = c.options.getGamma();
        if (NovaConfig.brightActive()) {
            if (savedGamma == null) savedGamma = gamma.getValue();
            if (gamma.getValue() < 15.0) setGamma(gamma, 16.0);
        } else if (savedGamma != null) {
            setGamma(gamma, savedGamma);
            savedGamma = null;
        }

        // Время и погода: только картинка на клиенте
        if (NovaConfig.on("time")) {
            long ticks = (long) (((NovaConfig.num("time.h") - 6 + 24) % 24) * 1000);
            c.world.setTimeOfDay(ticks);
        }
        if (NovaConfig.on("weather")) {
            int t = NovaConfig.idx("weather.t");
            c.world.setRainGradient(t >= 1 ? 1f : 0f);
            c.world.setThunderGradient(t >= 2 ? 1f : 0f);
        }
    }

    @SuppressWarnings("unchecked")
    private static void setGamma(net.minecraft.client.option.SimpleOption<Double> opt, double value) {
        ((SimpleOptionAccessor<Double>) (Object) opt).nova$setValue(value);
    }

    private static void restore(MinecraftClient c) {
        if (c.options == null) return;
        if (savedFov != null) { c.options.getFov().setValue(savedFov); savedFov = null; }
        if (savedGamma != null) { setGamma(c.options.getGamma(), savedGamma); savedGamma = null; }
    }

    /** Множитель зума для GameRenderer (плавно). */
    public static double zoomFactor() {
        double target = (NovaConfig.on("zoom") && zoomKey != null && zoomKey.isPressed()) ? NovaConfig.num("zoom.k") / 10.0 : 1.0;
        zoomCur += (target - zoomCur) * 0.25;
        return zoomCur;
    }
}
