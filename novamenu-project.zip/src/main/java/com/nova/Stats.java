package com.nova;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/** Статистика игрока с модом: время в мире, запуски, удары, убийства. Хранится в config/fl1xvisuals-stats.json. */
public final class Stats {
    public static long playMs = 0, sessionMs = 0, sessions = 0, hits = 0, kills = 0, bestStreak = 0;
    private static long lastTick = 0, lastSave = 0;

    private Stats() {}

    private static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("fl1xvisuals-stats.json"); }

    public static void load() {
        try {
            Path p = file();
            if (!Files.exists(p)) return;
            JsonObject o = JsonParser.parseString(Files.readString(p, StandardCharsets.UTF_8)).getAsJsonObject();
            playMs = o.has("playMs") ? o.get("playMs").getAsLong() : 0;
            sessions = o.has("sessions") ? o.get("sessions").getAsLong() : 0;
            hits = o.has("hits") ? o.get("hits").getAsLong() : 0;
            kills = o.has("kills") ? o.get("kills").getAsLong() : 0;
            bestStreak = o.has("bestStreak") ? o.get("bestStreak").getAsLong() : 0;
        } catch (Exception e) {
            System.err.println("[FL1X] не удалось прочитать статистику: " + e);
        }
    }

    public static void save() {
        try {
            JsonObject o = new JsonObject();
            o.addProperty("playMs", playMs);
            o.addProperty("sessions", sessions);
            o.addProperty("hits", hits);
            o.addProperty("kills", kills);
            o.addProperty("bestStreak", bestStreak);
            Files.writeString(file(), new GsonBuilder().setPrettyPrinting().create().toJson(o), StandardCharsets.UTF_8);
        } catch (Exception e) {
            System.err.println("[FL1X] не удалось сохранить статистику: " + e);
        }
    }

    /** Вызывается каждый тик клиента; время считается только пока игрок в мире. */
    public static void tick(boolean inWorld) {
        long now = System.currentTimeMillis();
        long dt = lastTick == 0 ? 0 : Math.min(1000, now - lastTick);
        lastTick = now;
        if (inWorld) { playMs += dt; sessionMs += dt; }
        if (now - lastSave > 60_000) { lastSave = now; save(); }
    }

    private static String dur(long ms) {
        long s = ms / 1000;
        long h = s / 3600, m = (s % 3600) / 60;
        if (h > 0) return h + " ч " + m + " мин";
        if (m > 0) return m + " мин " + (s % 60) + " с";
        return s + " с";
    }

    public static String text(String id) {
        switch (id) {
            case "st.nick": {
                MinecraftClient c = MinecraftClient.getInstance();
                return c.getSession() != null ? c.getSession().getUsername() : "-";
            }
            case "st.total": return dur(playMs);
            case "st.session": return dur(sessionMs);
            case "st.sessions": return String.valueOf(sessions);
            case "st.hits": return String.valueOf(hits);
            case "st.kills": return String.valueOf(kills);
            case "st.best": return String.valueOf(bestStreak);
            case "st.mods": {
                int n = 0;
                for (NovaConfig.Setting s : NovaConfig.ALL) if (s.type == NovaConfig.Type.MODULE && s.on()) n++;
                return String.valueOf(n);
            }
            case "up.version": return Updater.current();
            case "up.status": return Updater.status;
            default: return "";
        }
    }
}
