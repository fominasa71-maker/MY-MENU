package com.nova;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.DoubleFunction;

/** Все настройки мода: реестр, чтение и запись в config/novamenu.json. */
public final class NovaConfig {
    public enum Type { MODULE, HEADER, TOGGLE, SLIDER, CYCLE }

    public static final class Setting {
        public final String tab, id, label, parent;
        public final Type type;
        public final double min, max, step, def;
        public final String[] opts;
        public final DoubleFunction<String> fmt;
        public double value;

        Setting(String tab, String id, String label, String parent, Type type, double min, double max,
                double step, double def, String[] opts, DoubleFunction<String> fmt) {
            this.tab = tab; this.id = id; this.label = label; this.parent = parent; this.type = type;
            this.min = min; this.max = max; this.step = step; this.def = def; this.opts = opts;
            this.fmt = fmt != null ? fmt : N;
            this.value = def;
        }

        public boolean on() { return value >= 0.5; }

        public String text() {
            if (type == Type.CYCLE) return opts[(int) value];
            return fmt.apply(value);
        }
    }

    public static final String[] TABS = {"Руки", "Визуал", "Мир", "HUD", "Меню"};
    public static final String[] COLOR_NAMES = {"Белый", "Красный", "Жёлтый", "Зелёный", "Голубой"};
    public static final int[] COLORS = {0xFFFFFF, 0xFF4D4D, 0xFFD34D, 0x4DE08A, 0x4DC8FF};

    public static final List<Setting> ALL = new ArrayList<>();
    private static final Map<String, Setting> BY = new HashMap<>();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    static final DoubleFunction<String> N = v -> String.valueOf((int) Math.round(v));
    static final DoubleFunction<String> DEG = v -> (int) Math.round(v) + "°";
    static final DoubleFunction<String> PCT = v -> (int) Math.round(v) + "%";
    static final DoubleFunction<String> MUL10 = v -> "x" + (Math.round(v) / 10) + "." + (Math.round(v) % 10);
    static final DoubleFunction<String> TIME = v -> {
        int h = (int) Math.floor(v);
        int m = (int) Math.round((v - h) * 60);
        return String.format("%02d:%02d", h % 24, m);
    };

    private static void add(Setting s) { ALL.add(s); BY.put(s.id, s); }

    private static void module(String tab, String id, String label, boolean def) {
        add(new Setting(tab, id, label, null, Type.MODULE, 0, 1, 1, def ? 1 : 0, null, null));
    }
    private static void header(String tab, String label) {
        add(new Setting(tab, "h:" + label, label, null, Type.HEADER, 0, 0, 0, 0, null, null));
    }
    private static void toggle(String tab, String parent, String id, String label, boolean def) {
        add(new Setting(tab, id, label, parent, Type.TOGGLE, 0, 1, 1, def ? 1 : 0, null, null));
    }
    private static void slider(String tab, String parent, String id, String label, double min, double max,
                               double step, double def, DoubleFunction<String> fmt) {
        add(new Setting(tab, id, label, parent, Type.SLIDER, min, max, step, def, null, fmt));
    }
    private static void cycle(String tab, String parent, String id, String label, int def, String... opts) {
        add(new Setting(tab, id, label, parent, Type.CYCLE, 0, opts.length - 1, 1, def, opts, null));
    }

    static {
        String h = TABS[0], v = TABS[1], w = TABS[2], u = TABS[3], m = TABS[4];
        module(h, "hand", "Положение рук", true);
        slider(h, "hand", "hand.x", "Влево / вправо", -50, 50, 1, 0, N);
        slider(h, "hand", "hand.y", "Вверх / вниз", -50, 50, 1, 0, N);
        slider(h, "hand", "hand.z", "Ближе / дальше", -50, 50, 1, 0, N);
        slider(h, "hand", "hand.rx", "Наклон вперёд", -90, 90, 1, 0, DEG);
        slider(h, "hand", "hand.ry", "Поворот", -90, 90, 1, 0, DEG);
        slider(h, "hand", "hand.rz", "Крен", -90, 90, 1, 0, DEG);
        slider(h, "hand", "hand.sc", "Размер", 50, 150, 1, 100, PCT);
        toggle(h, "hand", "hand.off", "Показывать вторую руку", true);
        toggle(h, "hand", "hand.lefty", "Левая рука главная", false);
        module(h, "swing", "Скорость взмаха", false);
        slider(h, "swing", "swing.spd", "Скорость", 30, 250, 5, 100, PCT);
        module(h, "nofire", "Скрыть огонь на экране", false);

        module(v, "esp", "ESP: подсветка существ", false);
        module(v, "bright", "Fullbright", false);
        module(v, "hit", "Хитмаркер", false);
        slider(v, "hit", "hit.size", "Размер", 4, 24, 1, 8, N);
        slider(v, "hit", "hit.dur", "Длительность, мс", 100, 800, 25, 300, N);
        cycle(v, "hit", "hit.col", "Цвет", 1, COLOR_NAMES);

        module(w, "fov", "FOV", false);
        slider(w, "fov", "fov.v", "Угол обзора", 30, 110, 1, 90, DEG);
        module(w, "zoom", "Зум (держи клавишу C)", true);
        slider(w, "zoom", "zoom.k", "Кратность", 15, 60, 5, 30, MUL10);
        module(w, "time", "Время суток", false);
        slider(w, "time", "time.h", "Время", 0, 24, 0.5, 12, TIME);
        module(w, "weather", "Погода", false);
        cycle(w, "weather", "weather.t", "Тип", 0, "Ясно", "Дождь", "Гроза");
        module(w, "nohurt", "Без тряски при уроне", false);

        module(u, "cross", "Свой прицел", true);
        cycle(u, "cross", "cross.style", "Форма", 0, "Плюс", "Точка", "Кольцо");
        slider(u, "cross", "cross.size", "Размер", 2, 16, 1, 6, N);
        slider(u, "cross", "cross.gap", "Зазор", 0, 10, 1, 3, N);
        cycle(u, "cross", "cross.col", "Цвет", 0, COLOR_NAMES);
        module(u, "arr", "Список модулей", true);
        module(u, "wm", "Водяной знак", true);

        header(m, "Внешний вид");
        slider(m, null, "menu.hue", "Цвет акцента", 0, 360, 1, 260, DEG);
        toggle(m, null, "menu.rb", "Радужный акцент", false);
        slider(m, null, "menu.rspd", "Скорость радуги", 1, 10, 1, 4, N);
        cycle(m, null, "menu.theme", "Тема", 0, "Тёмная", "OLED", "Светлая");
        slider(m, null, "menu.pa", "Прозрачность панели", 30, 100, 1, 85, PCT);
        header(m, "Анимации");
        cycle(m, null, "menu.open", "Появление", 0, "Масштаб", "Слайд", "Фейд");
        slider(m, null, "menu.anim", "Скорость", 5, 25, 1, 10, MUL10);
        toggle(m, null, "menu.glow", "Свечение рамки", true);
        header(m, "Безопасность");
        cycle(m, null, "safe.mode", "Безопасный режим", 0, "Авто: на серверах", "Всегда", "Выключен");
    }

    private NovaConfig() {}

    public static Setting get(String id) { return BY.get(id); }
    public static boolean on(String id) { return BY.get(id).on(); }
    public static double num(String id) { return BY.get(id).value; }
    public static int idx(String id) { return (int) Math.round(BY.get(id).value); }

    public static List<Setting> forTab(String tab) {
        List<Setting> out = new ArrayList<>();
        for (Setting s : ALL) if (s.tab.equals(tab)) out.add(s);
        return out;
    }

    /** ESP и Fullbright: разрешены ли сейчас по настройке безопасного режима. */
    public static boolean riskyAllowed() {
        int mode = idx("safe.mode");
        if (mode == 1) return false;
        if (mode == 2) return true;
        MinecraftClient c = MinecraftClient.getInstance();
        return c.world == null || c.isInSingleplayer();
    }
    public static boolean espActive() { return on("esp") && riskyAllowed(); }
    public static boolean brightActive() { return on("bright") && riskyAllowed(); }

    /** Цвет акцента с учётом радужного режима. */
    public static int accent() {
        double hue = num("menu.hue");
        if (on("menu.rb")) hue = (System.currentTimeMillis() * num("menu.rspd") * 0.01) % 360;
        return hsv((float) hue, 0.62f, 1f);
    }

    public static int hsv(float hDeg, float s, float v) {
        float h = (hDeg % 360f) / 60f;
        int i = (int) Math.floor(h);
        float f = h - i, p = v * (1 - s), q = v * (1 - s * f), t = v * (1 - s * (1 - f));
        float r, g, b;
        switch (i % 6) {
            case 0: r = v; g = t; b = p; break;
            case 1: r = q; g = v; b = p; break;
            case 2: r = p; g = v; b = t; break;
            case 3: r = p; g = q; b = v; break;
            case 4: r = t; g = p; b = v; break;
            default: r = v; g = p; b = q; break;
        }
        return 0xFF000000 | ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (b * 255);
    }

    private static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("novamenu.json"); }

    public static void load() {
        try {
            Path p = file();
            if (!Files.exists(p)) return;
            JsonObject o = JsonParser.parseString(Files.readString(p, StandardCharsets.UTF_8)).getAsJsonObject();
            for (Setting s : ALL) {
                if (s.type == Type.HEADER || !o.has(s.id)) continue;
                s.value = Math.max(s.min, Math.min(s.max, o.get(s.id).getAsDouble()));
            }
        } catch (Exception e) {
            System.err.println("[NOVA] не удалось прочитать конфиг: " + e);
        }
    }

    public static void save() {
        try {
            JsonObject o = new JsonObject();
            for (Setting s : ALL) if (s.type != Type.HEADER) o.addProperty(s.id, s.value);
            Files.writeString(file(), GSON.toJson(o), StandardCharsets.UTF_8);
        } catch (Exception e) {
            System.err.println("[NOVA] не удалось сохранить конфиг: " + e);
        }
    }

    /** Вызывается после изменения настройки в меню. */
    public static void onChanged(Setting s) {
        if (s.id.equals("hand.lefty")) {
            MinecraftClient c = MinecraftClient.getInstance();
            if (c.options != null) c.options.getMainArm().setValue(s.on() ? net.minecraft.util.Arm.LEFT : net.minecraft.util.Arm.RIGHT);
        }
    }
}
