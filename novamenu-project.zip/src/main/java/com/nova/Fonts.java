package com.nova;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;

/** Свой (не ванильный) шрифт мода: assets/fl1xvisuals/font/main.ttf + main.json. */
public final class Fonts {
    public static final Identifier MAIN = Identifier.of("fl1xvisuals", "main");
    private static final Style STYLE = Style.EMPTY.withFont(MAIN);

    private Fonts() {}

    public static boolean on() { return NovaConfig.on("ui.font"); }

    public static MutableText t(String s) {
        MutableText m = Text.literal(s);
        return on() ? m.setStyle(STYLE) : m;
    }

    public static MutableText bold(String s) { return t(s).formatted(Formatting.BOLD); }

    public static Text apply(Text src) {
        return on() ? src.copy().styled(st -> st.withFont(MAIN)) : src;
    }

    public static int w(TextRenderer tr, String s) { return tr.getWidth(t(s)); }
}
