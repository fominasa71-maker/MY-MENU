package com.nova;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.client.option.ParticlesMode;

import java.util.HashMap;
import java.util.Map;

/** Вкладка «Оптимизация»: связь ползунков меню с настройками самой игры (они сами сохраняются в options.txt). */
public final class Opt {
    private static final String[] IDS = {"opt.dist", "opt.sim", "opt.ent", "opt.gfx", "opt.part", "opt.shadow",
            "opt.clouds", "opt.biome", "opt.mip", "opt.fps", "opt.vsync", "opt.gamma", "opt.fov"};
    private static Map<String, Double> backup = null;

    private Opt() {}

    private static void set(String id, double v) {
        NovaConfig.Setting s = NovaConfig.get(id);
        s.value = Math.max(s.min, Math.min(s.max, v));
    }

    /** Подтянуть текущие значения из игры (при открытии меню). */
    public static void pull() {
        GameOptions o = MinecraftClient.getInstance().options;
        if (o == null) return;
        set("opt.dist", o.getViewDistance().getValue());
        set("opt.sim", o.getSimulationDistance().getValue());
        set("opt.ent", o.getEntityDistanceScaling().getValue() * 100.0);
        set("opt.gfx", o.getGraphicsMode().getValue().ordinal());
        set("opt.part", o.getParticles().getValue().ordinal());
        set("opt.shadow", o.getEntityShadows().getValue() ? 1 : 0);
        set("opt.clouds", o.getCloudRenderMode().getValue() != CloudRenderMode.OFF ? 1 : 0);
        set("opt.biome", o.getBiomeBlendRadius().getValue());
        set("opt.mip", o.getMipmapLevels().getValue());
        set("opt.fps", o.getMaxFps().getValue());
        set("opt.vsync", o.getEnableVsync().getValue() ? 1 : 0);
        set("opt.gamma", Math.min(1.0, o.getGamma().getValue()) * 100.0);
        set("opt.fov", o.getFov().getValue());
    }

    private static void applyNoWrite(GameOptions o, NovaConfig.Setting s) {
        int iv = (int) Math.round(s.value);
        switch (s.id) {
            case "opt.dist": o.getViewDistance().setValue(iv); break;
            case "opt.sim": o.getSimulationDistance().setValue(iv); break;
            case "opt.ent": o.getEntityDistanceScaling().setValue(s.value / 100.0); break;
            case "opt.gfx": o.getGraphicsMode().setValue(GraphicsMode.values()[iv]); break;
            case "opt.part": o.getParticles().setValue(ParticlesMode.values()[iv]); break;
            case "opt.shadow": o.getEntityShadows().setValue(s.on()); break;
            case "opt.clouds": o.getCloudRenderMode().setValue(s.on() ? CloudRenderMode.FANCY : CloudRenderMode.OFF); break;
            case "opt.biome": o.getBiomeBlendRadius().setValue(iv); break;
            case "opt.mip": o.getMipmapLevels().setValue(iv); break;
            case "opt.fps": o.getMaxFps().setValue(iv); break;
            case "opt.vsync": o.getEnableVsync().setValue(s.on()); break;
            case "opt.gamma": if (!NovaConfig.brightActive()) o.getGamma().setValue(s.value / 100.0); break;
            case "opt.fov": o.getFov().setValue(iv); break;
            default: break;
        }
    }

    /** Применить изменённую настройку к игре и сразу записать options.txt. */
    public static void apply(NovaConfig.Setting s) {
        GameOptions o = MinecraftClient.getInstance().options;
        if (o == null) return;
        applyNoWrite(o, s);
        o.write();
    }

    private static void force(GameOptions o, String id, double v) {
        NovaConfig.Setting s = NovaConfig.get(id);
        set(id, v);
        applyNoWrite(o, s);
    }

    /** Режим максимального FPS: всё самое лёгкое. Прежние значения запоминаются. */
    public static void preset() {
        GameOptions o = MinecraftClient.getInstance().options;
        if (o == null) return;
        pull();
        if (backup == null) {
            backup = new HashMap<>();
            for (String id : IDS) backup.put(id, NovaConfig.num(id));
        }
        force(o, "opt.dist", 6);
        force(o, "opt.sim", 5);
        force(o, "opt.ent", 50);
        force(o, "opt.gfx", 0);
        force(o, "opt.part", 2);
        force(o, "opt.shadow", 0);
        force(o, "opt.clouds", 0);
        force(o, "opt.biome", 0);
        force(o, "opt.mip", 1);
        force(o, "opt.vsync", 0);
        o.write();
        NovaScreen.toast("Режим максимального FPS включён");
    }

    public static void restore() {
        GameOptions o = MinecraftClient.getInstance().options;
        if (o == null) return;
        if (backup == null) {
            NovaScreen.toast("Нечего возвращать");
            return;
        }
        for (String id : IDS) force(o, id, backup.get(id));
        backup = null;
        o.write();
        NovaScreen.toast("Прежние настройки возвращены");
    }
}
