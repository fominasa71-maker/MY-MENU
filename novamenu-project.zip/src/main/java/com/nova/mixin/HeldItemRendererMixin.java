package com.nova.mixin;

import com.nova.NovaConfig;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import net.minecraft.util.math.RotationAxis;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Положение, поворот и размер рук от первого лица. */
@Mixin(HeldItemRenderer.class)
public class HeldItemRendererMixin {
    @Inject(method = "renderFirstPersonItem", at = @At("HEAD"), cancellable = true)
    private void nova$hand(AbstractClientPlayerEntity player, float tickDelta, float pitch, Hand hand,
                           float swingProgress, ItemStack item, float equipProgress, MatrixStack matrices,
                           VertexConsumerProvider vertexConsumers, int light, CallbackInfo ci) {
        if (NovaConfig.on("sword") && hand == Hand.MAIN_HAND && swingProgress > 0f && item.getItem() instanceof SwordItem) {
            boolean r = player.getMainArm() == Arm.RIGHT;
            float sd = r ? 1f : -1f;
            float k = (float) NovaConfig.num("sword.k") / 100f;
            float sw = (float) Math.sin(swingProgress * Math.PI);
            float sq = (float) Math.sin(Math.sqrt(swingProgress) * Math.PI);
            switch (NovaConfig.idx("sword.t")) {
                case 0: // широкая дуга справа налево
                    matrices.translate(sd * -0.28f * k * sq, 0.06f * k * sw, 0f);
                    matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(sd * -65f * k * sw));
                    matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(sd * 30f * k * sq));
                    break;
                case 1: // рубящий сверху вниз
                    matrices.translate(0f, 0.18f * k * sw, -0.1f * k * sw);
                    matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-55f * k * sq));
                    matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(sd * -20f * k * sw));
                    break;
                default: // круговой взмах
                    matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(sd * -360f * k * swingProgress * 0.6f));
                    matrices.translate(0f, 0.05f * k * sw, 0f);
                    break;
            }
        }
        if (!NovaConfig.on("hand")) return;
        if (hand == Hand.OFF_HAND && !NovaConfig.on("hand.off")) {
            ci.cancel();
            return;
        }
        boolean right = (hand == Hand.MAIN_HAND) == (player.getMainArm() == Arm.RIGHT);
        float side = right ? 1f : -1f;
        matrices.translate(NovaConfig.num("hand.x") * 0.01 * side, NovaConfig.num("hand.y") * 0.01, NovaConfig.num("hand.z") * 0.01);
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees((float) NovaConfig.num("hand.rx")));
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees((float) NovaConfig.num("hand.ry") * side));
        matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees((float) NovaConfig.num("hand.rz") * side));
        float sc = (float) NovaConfig.num("hand.sc") / 100f;
        matrices.scale(sc, sc, sc);
    }
}
