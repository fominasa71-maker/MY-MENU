package com.nova.mixin;

import com.nova.Fonts;
import com.nova.NovaConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.world.level.storage.LevelSummary;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Свой дизайн карточек миров на экране выбора мира. */
@Mixin(targets = "net.minecraft.client.gui.screen.world.WorldListWidget$WorldEntry")
public abstract class WorldEntryMixin {
    @Shadow @Final private LevelSummary level;

    @Inject(method = "render", at = @At("HEAD"), cancellable = true, require = 0)
    private void fl1x$card(DrawContext ctx, int index, int y, int x, int entryWidth, int entryHeight,
                           int mouseX, int mouseY, boolean hovered, float tickDelta, CallbackInfo ci) {
        if (!NovaConfig.on("ui") || !NovaConfig.on("ui.worlds")) return;
        var tr = MinecraftClient.getInstance().textRenderer;
        int accent = NovaConfig.accent();
        int ac = accent & 0xFFFFFF;
        int x0 = x, y0 = y, x1 = x + entryWidth - 4, y1 = y + entryHeight - 2;
        float hv = hovered ? 1f : 0f;
        ctx.fill(x0, y0, x1, y1, hovered ? 0xE0182038 : 0xB00E1220);
        int line = hovered ? accent : ((ac) | 0x66000000);
        ctx.fill(x0, y0, x1, y0 + 1, line);
        ctx.fill(x0, y1 - 1, x1, y1, line);
        ctx.fill(x0, y0, x0 + 1, y1, line);
        ctx.fill(x1 - 1, y0, x1, y1, line);
        if (hovered) ctx.fill(x0 + 1, y0 + 1, x0 + 3, y1 - 1, accent);

        // «иконка» — первая буква названия на цветной плитке
        String name = level.getDisplayName();
        String letter = name.isEmpty() ? "?" : name.substring(0, 1).toUpperCase();
        int is = Math.min(entryHeight - 8, 30);
        int ix = x0 + 8, iy = y0 + (y1 - y0 - is) / 2;
        ctx.fill(ix, iy, ix + is, iy + is, (ac) | 0x40000000);
        ctx.fill(ix, iy, ix + is, iy + 1, accent);
        ctx.drawText(tr, Fonts.bold(letter), ix + (is - tr.getWidth(Fonts.bold(letter))) / 2, iy + (is - 8) / 2, 0xFFFFFFFF, true);

        int tx = ix + is + 8;
        ctx.drawText(tr, Fonts.bold(name), tx, y0 + 5, 0xFFFFFFFF, true);
        ctx.drawText(tr, Fonts.t(level.getName()), tx, y0 + 16, 0xFF8B93A7, false);
        ctx.drawText(tr, Fonts.apply(level.getDetails()), tx, y0 + 26, 0xFFA8B0C4, false);
        ci.cancel();
    }
}
