package com.nova.mixin;

import com.nova.Fonts;
import com.nova.NovaConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.PressableWidget;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Map;
import java.util.WeakHashMap;

/** Свои кнопки Minecraft: тёмная панель, неоновая рамка, плавное наведение и выезд кнопок на главном меню. */
@Mixin(PressableWidget.class)
public abstract class PressableWidgetMixin {
    private static final Map<PressableWidget, float[]> ST = new WeakHashMap<>(); // [hover, bornMs]

    private static int ca(int rgb, float a) {
        int al = Math.max(8, Math.min(255, (int) (a * 255)));
        return (al << 24) | (rgb & 0xFFFFFF);
    }

    @Inject(method = "renderWidget", at = @At("HEAD"), cancellable = true)
    private void fl1x$button(DrawContext ctx, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (!NovaConfig.on("ui") || !NovaConfig.on("ui.btn")) return;
        PressableWidget w = (PressableWidget) (Object) this;
        if (!(w instanceof ButtonWidget)) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        boolean hov = w.isHovered();
        boolean act = w.active;
        long now = System.currentTimeMillis();

        float[] st = ST.computeIfAbsent(w, k -> new float[]{0f, now % 1000000000L});
        st[0] += ((hov && act ? 1f : 0f) - st[0]) * 0.22f;
        float hv = st[0];

        // выезд кнопок на титульном экране
        float appear = 1f;
        if (mc.currentScreen instanceof TitleScreen) {
            float born = st[1];
            float t = ((now % 1000000000L) - born - w.getY() * 1.6f) / 420f;
            t = Math.max(0f, Math.min(1f, t));
            appear = 1f - (float) Math.pow(1f - t, 3);
        }

        int x = w.getX(), y = w.getY(), bw = w.getWidth(), bh = w.getHeight();
        int accent = NovaConfig.accent();
        int slide = (int) ((1f - appear) * -40f);
        ctx.getMatrices().push();
        ctx.getMatrices().translate(slide + hv * 2f, 0, 0);

        int base = act ? 0x141828 : 0x101218;
        ctx.fill(x, y, x + bw, y + bh, ca(base, (act ? 0.78f : 0.55f) * appear));
        // заполнение акцентом слева направо при наведении
        if (hv > 0.01f) ctx.fill(x, y, x + (int) (bw * hv), y + bh, ca(accent, 0.28f * hv * appear));
        int line = act ? mixColor(accent, hv) : 0xFFFFFF;
        float la = act ? (0.55f + 0.45f * hv) : 0.25f;
        ctx.fill(x, y, x + bw, y + 1, ca(line, la * appear));
        ctx.fill(x, y + bh - 1, x + bw, y + bh, ca(line, la * appear));
        ctx.fill(x, y, x + 1, y + bh, ca(line, la * appear));
        ctx.fill(x + bw - 1, y, x + bw, y + bh, ca(line, la * appear));
        if (act) ctx.fill(x, y + bh - 2, x + (int) (bw * hv), y + bh, ca(accent, appear));
        // лёгкое свечение вокруг при наведении
        if (hv > 0.05f) {
            ctx.fill(x - 1, y - 1, x + bw + 1, y, ca(accent, 0.18f * hv * appear));
            ctx.fill(x - 1, y + bh, x + bw + 1, y + bh + 1, ca(accent, 0.18f * hv * appear));
        }
        int txtCol = act ? (hv > 0.5f ? 0xFFFFFF : 0xE6E9F5) : 0xA0A0A0;
        ctx.drawCenteredTextWithShadow(mc.textRenderer, Fonts.apply(w.getMessage()),
                x + bw / 2, y + (bh - 8) / 2, ca(txtCol, appear));
        ctx.getMatrices().pop();
        ci.cancel();
    }

    private static int mixColor(int accent, float t) {
        int r = (int) (((accent >> 16) & 255) * (0.6f + 0.4f * t) + 255 * 0.0f);
        int g = (int) (((accent >> 8) & 255) * (0.6f + 0.4f * t));
        int b = (int) ((accent & 255) * (0.6f + 0.4f * t));
        return (r << 16) | (g << 8) | b;
    }
}
