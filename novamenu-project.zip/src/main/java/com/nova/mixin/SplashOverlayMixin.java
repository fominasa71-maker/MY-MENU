package com.nova.mixin;

import com.nova.NovaConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.SplashOverlay;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Util;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Вместо экрана Mojang — красный экран с логотипом FL1X и полоской загрузки. Рисуется поверх ванильного. */
@Mixin(SplashOverlay.class)
public abstract class SplashOverlayMixin {
    @Shadow private float progress;
    @Shadow private long reloadCompleteTime;

    private static float shown = 0f;

    @Inject(method = "render", at = @At("TAIL"))
    private void fl1x$splash(DrawContext ctx, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        long now = Util.getMeasuringTimeMs();
        float fade = reloadCompleteTime > -1L ? 1f - Math.min(1f, (now - reloadCompleteTime) / 600f) : 1f;
        if (fade <= 0.01f) return;
        int w = ctx.getScaledWindowWidth(), h = ctx.getScaledWindowHeight();
        int al = (int) (fade * 255);

        // красный вертикальный градиент
        ctx.fillGradient(0, 0, w, h, (al << 24) | 0xE01B24, (al << 24) | 0x5A0508);
        // мягкая виньетка по краям
        ctx.fillGradient(0, 0, w, h / 5, ((int) (fade * 90) << 24), 0x00000000);
        ctx.fillGradient(0, h - h / 5, w, h, 0x00000000, ((int) (fade * 140) << 24));

        // логотип
        String logo = "FL1X";
        float pulse = 1f + 0.03f * (float) Math.sin(now / 280.0);
        var ms = ctx.getMatrices();
        ms.push();
        ms.translate(w / 2f, h * 0.38f, 0f);
        ms.scale(5f * pulse, 5f * pulse, 1f);
        Text t = Text.literal(logo).formatted(Formatting.BOLD);
        var tr = net.minecraft.client.MinecraftClient.getInstance().textRenderer;
        int tw = tr.getWidth(t);
        ctx.drawText(tr, t, -tw / 2, -4, (al << 24) | 0xFFFFFF, true);
        ms.pop();
        Text sub = Text.literal("V I S U A L S").formatted(Formatting.BOLD);
        ctx.drawText(tr, sub, w / 2 - tr.getWidth(sub) / 2, (int) (h * 0.38f) + 24, (((int) (fade * 220)) << 24) | 0xFFD6D8, false);

        // полоска загрузки
        float target = reloadCompleteTime > -1L ? 1f : Math.min(0.97f, progress);
        shown += (target - shown) * 0.12f;
        int bw = Math.min(200, w - 60), bh = 5;
        int bx = (w - bw) / 2, by = (int) (h * 0.62f);
        ctx.fill(bx - 1, by - 1, bx + bw + 1, by + bh + 1, ((int) (fade * 200) << 24) | 0x2A0305);
        ctx.fill(bx, by, bx + bw, by + bh, ((int) (fade * 120) << 24) | 0x000000);
        int fw = (int) (bw * Math.max(0f, Math.min(1f, shown)));
        ctx.fill(bx, by, bx + fw, by + bh, (al << 24) | 0xFFFFFF);
        // блик на полоске
        int hx = bx + (int) ((now / 6) % (bw + 20)) - 20;
        int ha = Math.max(bx, hx), hb = Math.min(bx + fw, hx + 20);
        if (hb > ha) ctx.fill(ha, by, hb, by + bh, ((int) (fade * 140) << 24) | 0xFF8A90);
        String pct = (int) (shown * 100) + "%";
        ctx.drawText(tr, pct, w / 2 - tr.getWidth(pct) / 2, by + 10, (((int) (fade * 200)) << 24) | 0xFFFFFF, false);
    }
}
