package com.nova;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

import java.util.ArrayList;
import java.util.List;

/** Всё, что рисуется поверх игры: водяной знак, список модулей, прицел, хитмаркер. */
public final class Hud {
    public static long hitAt = 0;

    private Hud() {}

    public static void register() {
        HudRenderCallback.EVENT.register(Hud::render);
    }

    private static int ca(int rgb, float a) {
        int al = Math.max(4, Math.min(255, (int) (a * 255)));
        return (al << 24) | (rgb & 0xFFFFFF);
    }

    private static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options.hudHidden || mc.player == null) return;
        int accent = NovaConfig.accent();
        int w = ctx.getScaledWindowWidth(), h = ctx.getScaledWindowHeight();

        if (NovaConfig.on("wm") && !(mc.currentScreen instanceof NovaScreen)) {
            ctx.fill(2, 2, 2 + mc.textRenderer.getWidth("NOVA menu") + 8, 14, 0x90000000);
            ctx.fill(2, 2, 4, 14, accent);
            ctx.drawText(mc.textRenderer, "NOVA menu", 8, 4, accent, true);
        }

        if (NovaConfig.on("arr")) drawList(ctx, mc, w, accent);

        if (mc.currentScreen != null) return;
        if (!mc.options.getPerspective().isFirstPerson()) return;
        int cx = w / 2, cy = h / 2;

        if (NovaConfig.on("cross")) drawCross(ctx, cx, cy);
        if (NovaConfig.on("hit")) drawHit(ctx, cx, cy);
    }

    private static void drawList(DrawContext ctx, MinecraftClient mc, int w, int accent) {
        List<String> names = new ArrayList<>();
        for (NovaConfig.Setting s : NovaConfig.ALL) {
            if (s.type != NovaConfig.Type.MODULE || !s.on()) continue;
            if (s.id.equals("arr") || s.id.equals("wm")) continue;
            if ((s.id.equals("esp") || s.id.equals("bright")) && !NovaConfig.riskyAllowed()) continue;
            names.add(s.label);
        }
        names.sort((a, b) -> mc.textRenderer.getWidth(b) - mc.textRenderer.getWidth(a));
        int y = 2;
        for (int i = 0; i < names.size(); i++) {
            String n = names.get(i);
            int tw = mc.textRenderer.getWidth(n);
            int col = NovaConfig.hsv((float) ((NovaConfig.num("menu.hue") + i * 14) % 360), 0.6f, 1f);
            if (NovaConfig.on("menu.rb")) col = NovaConfig.hsv((float) ((System.currentTimeMillis() * NovaConfig.num("menu.rspd") * 0.01 + i * 14) % 360), 0.6f, 1f);
            ctx.fill(w - tw - 8, y, w - 2, y + 11, 0x90000000);
            ctx.fill(w - 4, y, w - 2, y + 11, col);
            ctx.drawText(mc.textRenderer, n, w - tw - 6, y + 2, 0xFFFFFFFF, false);
            y += 11;
        }
    }

    private static void drawCross(DrawContext ctx, int cx, int cy) {
        int col = 0xFF000000 | NovaConfig.COLORS[NovaConfig.idx("cross.col")];
        int size = (int) NovaConfig.num("cross.size"), gap = (int) NovaConfig.num("cross.gap");
        int style = NovaConfig.idx("cross.style");
        if (style == 0) {
            ctx.fill(cx - 1, cy - gap - size, cx + 1, cy - gap, col);
            ctx.fill(cx - 1, cy + gap, cx + 1, cy + gap + size, col);
            ctx.fill(cx - gap - size, cy - 1, cx - gap, cy + 1, col);
            ctx.fill(cx + gap, cy - 1, cx + gap + size, cy + 1, col);
        } else if (style == 1) {
            int r = Math.max(1, size / 2);
            ctx.fill(cx - r, cy - r, cx + r, cy + r, col);
        } else {
            double r = size + gap;
            for (int i = 0; i < 40; i++) {
                double a = i * Math.PI * 2 / 40;
                int x = cx + (int) Math.round(Math.cos(a) * r), y = cy + (int) Math.round(Math.sin(a) * r);
                ctx.fill(x, y, x + 1, y + 1, col);
            }
        }
    }

    private static void drawHit(DrawContext ctx, int cx, int cy) {
        long dt = System.currentTimeMillis() - hitAt;
        double dur = NovaConfig.num("hit.dur");
        if (hitAt == 0 || dt > dur) return;
        float a = 1f - dt / (float) dur;
        int col = ca(NovaConfig.COLORS[NovaConfig.idx("hit.col")], a);
        int size = (int) NovaConfig.num("hit.size");
        int start = 3 + (int) ((1 - a) * 2);
        for (int k = start; k < start + size; k++) {
            ctx.fill(cx + k, cy + k, cx + k + 1, cy + k + 1, col);
            ctx.fill(cx - k - 1, cy + k, cx - k, cy + k + 1, col);
            ctx.fill(cx + k, cy - k - 1, cx + k + 1, cy - k, col);
            ctx.fill(cx - k - 1, cy - k - 1, cx - k, cy - k, col);
        }
    }
}
