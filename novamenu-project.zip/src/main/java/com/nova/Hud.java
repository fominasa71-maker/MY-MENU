package com.nova;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.List;

/** Всё, что рисуется поверх игры: водяной знак с FPS и пингом, список модулей, прицел, хитмаркер, баннер убийства. */
public final class Hud {
    public static long hitAt = 0;
    private static long bannerAt = 0;
    private static String bannerText = "";
    private static int bannerStreak = 1;
    private static long sayAt = 0;
    private static String sayText = "";

    private Hud() {}

    public static void register() {
        HudRenderCallback.EVENT.register(Hud::render);
    }

    public static void banner(String name, int streak) {
        bannerAt = System.currentTimeMillis();
        bannerText = name;
        bannerStreak = streak;
    }

    public static void say(String text) {
        sayAt = System.currentTimeMillis();
        sayText = text;
    }

    private static int ca(int rgb, float a) {
        int al = Math.max(4, Math.min(255, (int) (a * 255)));
        return (al << 24) | (rgb & 0xFFFFFF);
    }

    private static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options.hudHidden || mc.player == null) return;
        int accent = NovaConfig.accent();
        int w = ctx.getScaledWindowWidth(), h = ctx.getScaledWindowHeight();

        if (NovaConfig.on("wm")) drawWatermark(ctx, mc, accent);
        if (NovaConfig.on("arr")) drawList(ctx, mc, w);
        if (System.currentTimeMillis() - sayAt < 2000) {
            ctx.drawCenteredTextWithShadow(mc.textRenderer, Fonts.t(sayText), w / 2, h - 60, 0xFFFFD34D);
        }
        if (mc.currentScreen != null) return;
        if (!mc.options.getPerspective().isFirstPerson()) return;
        int cx = w / 2, cy = h / 2;

        if (NovaConfig.on("cross")) drawCross(ctx, cx, cy);
        if (NovaConfig.on("hit")) drawHit(ctx, cx, cy);
        if (NovaConfig.on("thud")) drawTarget(ctx, mc, cx, cy, accent);
        if (NovaConfig.on("kbanner")) drawBanner(ctx, mc, w, h, accent);
    }

    private static final java.time.format.DateTimeFormatter TIME_FMT = java.time.format.DateTimeFormatter.ofPattern("HH:mm");

    /** [Время] | [X, Y, Z] | [FPS] | FL1X — плашка с неоновой обводкой в правом верхнем углу. */
    private static void drawWatermark(DrawContext ctx, MinecraftClient mc, int accent) {
        List<String> parts = new ArrayList<>();
        List<Integer> cols = new ArrayList<>();
        if (NovaConfig.on("wm.time")) {
            parts.add(java.time.LocalTime.now().format(TIME_FMT));
            cols.add(0xFFFFFFFF);
        }
        if (NovaConfig.on("wm.coords") && mc.player != null) {
            parts.add(mc.player.getBlockX() + ", " + mc.player.getBlockY() + ", " + mc.player.getBlockZ());
            cols.add(0xFFC9CFE0);
        }
        if (NovaConfig.on("wm.fps")) {
            int fps = mc.getCurrentFps();
            parts.add(fps + " FPS");
            cols.add(fps >= 60 ? 0xFF4DE08A : (fps >= 30 ? 0xFFFFD34D : 0xFFFF6B6B));
        }
        parts.add("FL1X");
        cols.add(accent);

        int sep = 11;
        int total = 0;
        for (int i = 0; i < parts.size(); i++) total += Fonts.w(mc.textRenderer, parts.get(i)) + (i > 0 ? sep : 0);
        int pad = 7, hgt = 16;
        int bw = total + pad * 2;
        int w = ctx.getScaledWindowWidth();
        int x0 = w - bw - 4, y0 = 4;
        int x1 = x0 + bw, y1 = y0 + hgt;

        // свечение и подложка
        ctx.fill(x0 - 2, y0 - 2, x1 + 2, y1 + 2, (accent & 0xFFFFFF) | 0x12000000);
        ctx.fill(x0 - 1, y0 - 1, x1 + 1, y1 + 1, (accent & 0xFFFFFF) | 0x24000000);
        ctx.fill(x0, y0, x1, y1, 0xD00B0E18);
        // обводка
        ctx.fill(x0, y0, x1, y0 + 1, accent);
        ctx.fill(x0, y1 - 1, x1, y1, accent);
        ctx.fill(x0, y0, x0 + 1, y1, accent);
        ctx.fill(x1 - 1, y0, x1, y1, accent);
        // бегущий блик по верхней кромке
        int sweepW = 28;
        int sx = x0 + (int) ((System.currentTimeMillis() / 12) % (bw + sweepW)) - sweepW;
        int sa = Math.max(x0, sx), sb = Math.min(x1, sx + sweepW);
        if (sb > sa) ctx.fill(sa, y0, sb, y0 + 1, 0xF0FFFFFF);

        int x = x0 + pad;
        for (int i = 0; i < parts.size(); i++) {
            if (i > 0) {
                ctx.drawText(mc.textRenderer, Fonts.t("|"), x + 3, y0 + 4, (accent & 0xFFFFFF) | 0xAA000000, false);
                x += sep;
            }
            ctx.drawText(mc.textRenderer, Fonts.t(parts.get(i)), x, y0 + 4, cols.get(i), true);
            x += Fonts.w(mc.textRenderer, parts.get(i));
        }
    }

    // ---- Target HUD: ник и броня, без здоровья ----
    private static net.minecraft.entity.player.PlayerEntity thudPlayer = null;
    private static long thudSeen = 0;

    private static void drawTarget(DrawContext ctx, MinecraftClient mc, int cx, int cy, int accent) {
        long now = System.currentTimeMillis();
        if (mc.targetedEntity instanceof net.minecraft.entity.player.PlayerEntity p && p != mc.player) {
            thudPlayer = p; thudSeen = now;
        } else if (NovaClient.recentTarget() instanceof net.minecraft.entity.player.PlayerEntity p2 && p2 != mc.player) {
            thudPlayer = p2; thudSeen = now;
        }
        if (thudPlayer == null) return;
        long age = now - thudSeen;
        if (age > 1200 || thudPlayer.isRemoved()) { thudPlayer = null; return; }
        float a = age < 900 ? 1f : 1f - (age - 900) / 300f;

        String name = thudPlayer.getName().getString();
        int tw = Fonts.w(mc.textRenderer, name);
        int bw = Math.max(98, tw + 16), bh = 34;
        int x0 = cx + 26, y0 = cy + 10, x1 = x0 + bw, y1 = y0 + bh;
        int ac = accent & 0xFFFFFF;
        ctx.fill(x0 - 1, y0 - 1, x1 + 1, y1 + 1, ca(ac, 0.14f * a));
        ctx.fill(x0, y0, x1, y1, ca(0x0B0E18, 0.82f * a));
        ctx.fill(x0, y0, x1, y0 + 1, ca(ac, a));
        ctx.fill(x0, y1 - 1, x1, y1, ca(ac, a));
        ctx.fill(x0, y0, x0 + 1, y1, ca(ac, a));
        ctx.fill(x1 - 1, y0, x1, y1, ca(ac, a));
        ctx.fill(x0 + 1, y0 + 1, x0 + 3, y1 - 1, ca(ac, a));
        ctx.drawText(mc.textRenderer, Fonts.bold(name), x0 + 8, y0 + 5, ca(0xFFFFFF, a), true);

        net.minecraft.entity.EquipmentSlot[] slots = {
                net.minecraft.entity.EquipmentSlot.HEAD, net.minecraft.entity.EquipmentSlot.CHEST,
                net.minecraft.entity.EquipmentSlot.LEGS, net.minecraft.entity.EquipmentSlot.FEET};
        int ix = x0 + 8, iy = y0 + 16;
        for (net.minecraft.entity.EquipmentSlot sl : slots) {
            net.minecraft.item.ItemStack st = thudPlayer.getEquippedStack(sl);
            if (st.isEmpty()) {
                ctx.fill(ix + 3, iy + 3, ix + 13, iy + 13, ca(0xFFFFFF, 0.10f * a));
            } else if (a > 0.6f) {
                ctx.drawItem(st, ix, iy);
            }
            ix += 20;
        }
    }

    private static void drawList(DrawContext ctx, MinecraftClient mc, int w) {
        List<String> names = new ArrayList<>();
        for (NovaConfig.Setting s : NovaConfig.ALL) {
            if (s.type != NovaConfig.Type.MODULE || !s.on()) continue;
            if (s.id.equals("arr") || s.id.equals("wm") || s.id.equals("ui")) continue;
            if ((s.id.equals("esp") || s.id.equals("bright")) && !NovaConfig.riskyAllowed()) continue;
            names.add(s.label);
        }
        names.sort((a, b) -> Fonts.w(mc.textRenderer, b) - Fonts.w(mc.textRenderer, a));
        int y = NovaConfig.on("wm") ? 26 : 2;
        double hue = NovaConfig.hue();
        for (int i = 0; i < names.size(); i++) {
            String n = names.get(i);
            int tw = Fonts.w(mc.textRenderer, n);
            int col = NovaConfig.hsv((float) ((hue + i * 14) % 360), 0.6f, 1f);
            ctx.fill(w - tw - 8, y, w - 2, y + 11, 0x90000000);
            ctx.fill(w - 4, y, w - 2, y + 11, col);
            ctx.drawText(mc.textRenderer, Fonts.t(n), w - tw - 6, y + 2, 0xFFFFFFFF, false);
            y += 11;
        }
    }

    private static void drawCross(DrawContext ctx, int cx, int cy) {
        int col = 0xFF000000 | NovaConfig.COLORS[NovaConfig.idx("cross.col")];
        int size = (int) NovaConfig.num("cross.size"), gap = (int) NovaConfig.num("cross.gap");
        int style = NovaConfig.idx("cross.style");
        if (style == 0) {
            ctx.fill(cx - 1, cy - gap - size, cx + 1, cy - gap, col);
            ctx.fill(cx - 1, cy + gap, cx + 1, cy + gap + size, col);
            ctx.fill(cx - gap - size, cy - 1, cx - gap, cy + 1, col);
            ctx.fill(cx + gap, cy - 1, cx + gap + size, cy + 1, col);
        } else if (style == 1) {
            int r = Math.max(1, size / 2);
            ctx.fill(cx - r, cy - r, cx + r, cy + r, col);
        } else {
            double r = size + gap;
            for (int i = 0; i < 40; i++) {
                double a = i * Math.PI * 2 / 40;
                int x = cx + (int) Math.round(Math.cos(a) * r), y = cy + (int) Math.round(Math.sin(a) * r);
                ctx.fill(x, y, x + 1, y + 1, col);
            }
        }
    }

    private static void drawHit(DrawContext ctx, int cx, int cy) {
        long dt = System.currentTimeMillis() - hitAt;
        double dur = NovaConfig.num("hit.dur");
        if (hitAt == 0 || dt > dur) return;
        float a = 1f - dt / (float) dur;
        int col = ca(NovaConfig.COLORS[NovaConfig.idx("hit.col")], a);
        int size = (int) NovaConfig.num("hit.size");
        int style = NovaConfig.idx("hit.style");
        if (style == 0) {
            int start = 3 + (int) ((1 - a) * 2);
            for (int k = start; k < start + size; k++) {
                ctx.fill(cx + k, cy + k, cx + k + 1, cy + k + 1, col);
                ctx.fill(cx - k - 1, cy + k, cx - k, cy + k + 1, col);
                ctx.fill(cx + k, cy - k - 1, cx + k + 1, cy - k, col);
                ctx.fill(cx - k - 1, cy - k - 1, cx - k, cy - k, col);
            }
        } else if (style == 1) {
            int r = Math.max(1, size / 2);
            ctx.fill(cx - r, cy - r, cx + r, cy + r, col);
        } else {
            double r = size * (1.0 + (1 - a));
            for (int i = 0; i < 36; i++) {
                double an = i * Math.PI * 2 / 36;
                int x = cx + (int) Math.round(Math.cos(an) * r), y = cy + (int) Math.round(Math.sin(an) * r);
                ctx.fill(x, y, x + 1, y + 1, col);
            }
        }
    }

    private static void drawBanner(DrawContext ctx, MinecraftClient mc, int w, int h, int accent) {
        long dt = System.currentTimeMillis() - bannerAt;
        double dur = NovaConfig.num("kbanner.dur");
        if (bannerAt == 0 || dt > dur) return;
        float p = (float) (dt / dur);
        float fade = p > 0.8f ? (1f - p) / 0.2f : 1f;
        int style = NovaConfig.idx("kbanner.t");
        float inP = Math.min(1f, p * 4f);
        float ease = 1f - (float) Math.pow(1f - inP, 3);
        float y = h * 0.22f;
        float scale = 2f;
        float alpha = fade;
        if (style == 0) y = -20f + (h * 0.22f + 20f) * ease;
        else if (style == 1) scale = 0.5f + 1.5f * ease + (inP < 1f ? 0.25f * (float) Math.sin(inP * Math.PI) : 0f);
        else alpha = fade * ease;
        if (alpha < 0.08f) return;
        MatrixStack ms = ctx.getMatrices();
        ms.push();
        ms.translate(w / 2f, y, 0f);
        ms.scale(scale, scale, 1f);
        Text title = Fonts.bold("УБИЙСТВО");
        int tw = mc.textRenderer.getWidth(title);
        ctx.drawText(mc.textRenderer, title, -tw / 2, 0, ca(accent, alpha), true);
        ms.pop();
        String sub = bannerText + (bannerStreak > 1 ? "  x" + bannerStreak : "");
        ctx.drawCenteredTextWithShadow(mc.textRenderer, Fonts.t(sub), w / 2, (int) (y + 8 * scale + 4), ca(0xFFFFFF, alpha));
    }
}
