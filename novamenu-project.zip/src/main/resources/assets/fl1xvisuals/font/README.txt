main.ttf - шрифт мода. Сейчас тут Inter SemiBold (лицензия SIL OFL 1.1, https://rsms.me/inter).
Чтобы поставить свой шрифт: замени этот файл своим .ttf с таким же именем main.ttf и пересобери мод.
