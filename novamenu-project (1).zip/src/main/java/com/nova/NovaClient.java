package com.nova;

import com.nova.mixin.SimpleOptionAccessor;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.LivingEntity;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import org.lwjgl.glfw.GLFW;

public class NovaClient implements ClientModInitializer {
    public static KeyBinding menuKey;
    public static KeyBinding zoomKey;

    private static Integer savedFov = null;
    private static Double savedGamma = null;
    private static double zoomCur = 1.0;

    // слежение за целью: нужно, чтобы понять, что убийство было нашим
    private static LivingEntity target = null;
    private static long targetAt = 0;
    private static long lastKillAt = 0;
    private static int streak = 0;

    @Override
    public void onInitializeClient() {
        NovaConfig.load();

        menuKey = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.fl1xvisuals.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_INSERT, "category.fl1xvisuals"));
        zoomKey = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.fl1xvisuals.zoom", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C, "category.fl1xvisuals"));

        ClientTickEvents.END_CLIENT_TICK.register(NovaClient::tick);
        ClientLifecycleEvents.CLIENT_STOPPING.register(c -> { restore(c); NovaConfig.save(); });
        Hud.register();

        // Кнопка FL1X на титульном экране и в меню паузы: меню открывается и на телефоне без клавиатуры.
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (screen instanceof TitleScreen || screen instanceof GameMenuScreen) {
                Screens.getButtons(screen).add(ButtonWidget.builder(Text.literal("FL1X"),
                        b -> client.setScreen(new NovaScreen(screen))).dimensions(6, 6, 60, 20).build());
            }
        });

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.isClient && entity instanceof LivingEntity le && player == MinecraftClient.getInstance().player) {
                Effects.onHit(le);
                target = le;
                targetAt = System.currentTimeMillis();
            }
            return ActionResult.PASS;
        });
    }

    // ---- клавиши и кнопки меню ----

    public static String keyText(String id) {
        KeyBinding kb = id.equals("bind.menu") ? menuKey : zoomKey;
        return kb == null ? "-" : kb.getBoundKeyLocalizedText().getString();
    }

    public static void rebind(String id, int keyCode, int scanCode) {
        KeyBinding kb = id.equals("bind.menu") ? menuKey : zoomKey;
        if (kb == null) return;
        kb.setBoundKey(InputUtil.fromKeyCode(keyCode, scanCode));
        KeyBinding.updateKeysByCode();
        MinecraftClient.getInstance().options.write();
    }

    public static void action(String id) {
        Effects.test(id);
    }

    // ---- тик ----

    private static void tick(MinecraftClient c) {
        while (menuKey.wasPressed()) {
            c.setScreen(new NovaScreen(null));
        }
        if (c.player == null || c.world == null) { target = null; return; }

        trackKill();

        var fov = c.options.getFov();
        if (NovaConfig.on("fov")) {
            if (savedFov == null) savedFov = fov.getValue();
            int want = (int) NovaConfig.num("fov.v");
            if (fov.getValue() != want) fov.setValue(want);
        } else if (savedFov != null) {
            fov.setValue(savedFov);
            savedFov = null;
        }

        var gamma = c.options.getGamma();
        if (NovaConfig.brightActive()) {
            if (savedGamma == null) savedGamma = gamma.getValue();
            if (gamma.getValue() < 15.0) setGamma(gamma, 16.0);
        } else if (savedGamma != null) {
            setGamma(gamma, savedGamma);
            savedGamma = null;
        }

        if (NovaConfig.on("time")) {
            long ticks = (long) (((NovaConfig.num("time.h") - 6 + 24) % 24) * 1000);
            c.world.setTimeOfDay(ticks);
        }
        if (NovaConfig.on("weather")) {
            int t = NovaConfig.idx("weather.t");
            c.world.setRainGradient(t >= 1 ? 1f : 0f);
            c.world.setThunderGradient(t >= 2 ? 1f : 0f);
        }
    }

    private static void trackKill() {
        if (target == null) return;
        long now = System.currentTimeMillis();
        if (now - targetAt > 5000) { target = null; return; }
        if (target.getHealth() <= 0f) {
            streak = (now - lastKillAt < 6000) ? streak + 1 : 1;
            lastKillAt = now;
            Effects.onKill(target, streak);
            target = null;
        } else if (target.isRemoved()) {
            target = null;
        }
    }

    @SuppressWarnings("unchecked")
    private static void setGamma(net.minecraft.client.option.SimpleOption<Double> opt, double value) {
        ((SimpleOptionAccessor<Double>) (Object) opt).nova$setValue(value);
    }

    private static void restore(MinecraftClient c) {
        if (c.options == null) return;
        if (savedFov != null) { c.options.getFov().setValue(savedFov); savedFov = null; }
        if (savedGamma != null) { setGamma(c.options.getGamma(), savedGamma); savedGamma = null; }
    }

    /** Множитель зума для GameRenderer (плавно). */
    public static double zoomFactor() {
        double want = (NovaConfig.on("zoom") && zoomKey != null && zoomKey.isPressed()) ? NovaConfig.num("zoom.k") / 10.0 : 1.0;
        zoomCur += (want - zoomCur) * 0.25;
        return zoomCur;
    }
}
