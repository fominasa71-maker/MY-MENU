package com.nova;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.List;

/** Всё, что рисуется поверх игры: водяной знак с FPS и пингом, список модулей, прицел, хитмаркер, баннер убийства. */
public final class Hud {
    public static long hitAt = 0;
    private static long bannerAt = 0;
    private static String bannerText = "";
    private static int bannerStreak = 1;
    private static long sayAt = 0;
    private static String sayText = "";

    private Hud() {}

    public static void register() {
        HudRenderCallback.EVENT.register(Hud::render);
    }

    public static void banner(String name, int streak) {
        bannerAt = System.currentTimeMillis();
        bannerText = name;
        bannerStreak = streak;
    }

    public static void say(String text) {
        sayAt = System.currentTimeMillis();
        sayText = text;
    }

    private static int ca(int rgb, float a) {
        int al = Math.max(4, Math.min(255, (int) (a * 255)));
        return (al << 24) | (rgb & 0xFFFFFF);
    }

    private static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options.hudHidden || mc.player == null) return;
        int accent = NovaConfig.accent();
        int w = ctx.getScaledWindowWidth(), h = ctx.getScaledWindowHeight();

        if (NovaConfig.on("wm")) drawWatermark(ctx, mc, accent);
        if (NovaConfig.on("arr")) drawList(ctx, mc, w);
        if (System.currentTimeMillis() - sayAt < 2000) {
            ctx.drawCenteredTextWithShadow(mc.textRenderer, sayText, w / 2, h - 60, 0xFFFFD34D);
        }
        if (mc.currentScreen != null) return;
        if (!mc.options.getPerspective().isFirstPerson()) return;
        int cx = w / 2, cy = h / 2;

        if (NovaConfig.on("cross")) drawCross(ctx, cx, cy);
        if (NovaConfig.on("hit")) drawHit(ctx, cx, cy);
        if (NovaConfig.on("kbanner")) drawBanner(ctx, mc, w, h, accent);
    }

    private static String pingText(MinecraftClient mc) {
        if (mc.isInSingleplayer()) return "локально";
        PlayerListEntry e = mc.getNetworkHandler() != null ? mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid()) : null;
        return (e == null ? 0 : e.getLatency()) + " ms";
    }

    private static int pingColor(MinecraftClient mc) {
        if (mc.isInSingleplayer()) return 0xFF8B93A7;
        PlayerListEntry e = mc.getNetworkHandler() != null ? mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid()) : null;
        int ms = e == null ? 0 : e.getLatency();
        return ms < 60 ? 0xFF4DE08A : (ms < 120 ? 0xFFFFD34D : 0xFFFF6B6B);
    }

    private static void drawWatermark(DrawContext ctx, MinecraftClient mc, int accent) {
        List<String> parts = new ArrayList<>();
        List<Integer> cols = new ArrayList<>();
        parts.add(NovaConfig.NAME);
        cols.add(accent);
        if (NovaConfig.on("wm.fps")) {
            int fps = mc.getCurrentFps();
            parts.add(fps + " FPS");
            cols.add(fps >= 60 ? 0xFF4DE08A : (fps >= 30 ? 0xFFFFD34D : 0xFFFF6B6B));
        }
        if (NovaConfig.on("wm.ping")) {
            parts.add(pingText(mc));
            cols.add(pingColor(mc));
        }
        int total = 6;
        for (int i = 0; i < parts.size(); i++) total += mc.textRenderer.getWidth(parts.get(i)) + (i > 0 ? 12 : 0);
        ctx.fill(2, 2, 2 + total + 4, 15, 0x90000000);
        ctx.fill(2, 2, 4, 15, accent);
        int x = 8;
        for (int i = 0; i < parts.size(); i++) {
            if (i > 0) {
                ctx.drawText(mc.textRenderer, "|", x + 2, 5, 0xFF666C80, false);
                x += 12;
            }
            ctx.drawText(mc.textRenderer, parts.get(i), x, 5, cols.get(i), true);
            x += mc.textRenderer.getWidth(parts.get(i));
        }
    }

    private static void drawList(DrawContext ctx, MinecraftClient mc, int w) {
        List<String> names = new ArrayList<>();
        for (NovaConfig.Setting s : NovaConfig.ALL) {
            if (s.type != NovaConfig.Type.MODULE || !s.on()) continue;
            if (s.id.equals("arr") || s.id.equals("wm") || s.id.equals("ui")) continue;
            if ((s.id.equals("esp") || s.id.equals("bright")) && !NovaConfig.riskyAllowed()) continue;
            names.add(s.label);
        }
        names.sort((a, b) -> mc.textRenderer.getWidth(b) - mc.textRenderer.getWidth(a));
        int y = 2;
        double hue = NovaConfig.hue();
        for (int i = 0; i < names.size(); i++) {
            String n = names.get(i);
            int tw = mc.textRenderer.getWidth(n);
            int col = NovaConfig.hsv((float) ((hue + i * 14) % 360), 0.6f, 1f);
            ctx.fill(w - tw - 8, y, w - 2, y + 11, 0x90000000);
            ctx.fill(w - 4, y, w - 2, y + 11, col);
            ctx.drawText(mc.textRenderer, n, w - tw - 6, y + 2, 0xFFFFFFFF, false);
            y += 11;
        }
    }

    private static void drawCross(DrawContext ctx, int cx, int cy) {
        int col = 0xFF000000 | NovaConfig.COLORS[NovaConfig.idx("cross.col")];
        int size = (int) NovaConfig.num("cross.size"), gap = (int) NovaConfig.num("cross.gap");
        int style = NovaConfig.idx("cross.style");
        if (style == 0) {
            ctx.fill(cx - 1, cy - gap - size, cx + 1, cy - gap, col);
            ctx.fill(cx - 1, cy + gap, cx + 1, cy + gap + size, col);
            ctx.fill(cx - gap - size, cy - 1, cx - gap, cy + 1, col);
            ctx.fill(cx + gap, cy - 1, cx + gap + size, cy + 1, col);
        } else if (style == 1) {
            int r = Math.max(1, size / 2);
            ctx.fill(cx - r, cy - r, cx + r, cy + r, col);
        } else {
            double r = size + gap;
            for (int i = 0; i < 40; i++) {
                double a = i * Math.PI * 2 / 40;
                int x = cx + (int) Math.round(Math.cos(a) * r), y = cy + (int) Math.round(Math.sin(a) * r);
                ctx.fill(x, y, x + 1, y + 1, col);
            }
        }
    }

    private static void drawHit(DrawContext ctx, int cx, int cy) {
        long dt = System.currentTimeMillis() - hitAt;
        double dur = NovaConfig.num("hit.dur");
        if (hitAt == 0 || dt > dur) return;
        float a = 1f - dt / (float) dur;
        int col = ca(NovaConfig.COLORS[NovaConfig.idx("hit.col")], a);
        int size = (int) NovaConfig.num("hit.size");
        int style = NovaConfig.idx("hit.style");
        if (style == 0) {
            int start = 3 + (int) ((1 - a) * 2);
            for (int k = start; k < start + size; k++) {
                ctx.fill(cx + k, cy + k, cx + k + 1, cy + k + 1, col);
                ctx.fill(cx - k - 1, cy + k, cx - k, cy + k + 1, col);
                ctx.fill(cx + k, cy - k - 1, cx + k + 1, cy - k, col);
                ctx.fill(cx - k - 1, cy - k - 1, cx - k, cy - k, col);
            }
        } else if (style == 1) {
            int r = Math.max(1, size / 2);
            ctx.fill(cx - r, cy - r, cx + r, cy + r, col);
        } else {
            double r = size * (1.0 + (1 - a));
            for (int i = 0; i < 36; i++) {
                double an = i * Math.PI * 2 / 36;
                int x = cx + (int) Math.round(Math.cos(an) * r), y = cy + (int) Math.round(Math.sin(an) * r);
                ctx.fill(x, y, x + 1, y + 1, col);
            }
        }
    }

    private static void drawBanner(DrawContext ctx, MinecraftClient mc, int w, int h, int accent) {
        long dt = System.currentTimeMillis() - bannerAt;
        double dur = NovaConfig.num("kbanner.dur");
        if (bannerAt == 0 || dt > dur) return;
        float p = (float) (dt / dur);
        float fade = p > 0.8f ? (1f - p) / 0.2f : 1f;
        int style = NovaConfig.idx("kbanner.t");
        float inP = Math.min(1f, p * 4f);
        float ease = 1f - (float) Math.pow(1f - inP, 3);
        float y = h * 0.22f;
        float scale = 2f;
        float alpha = fade;
        if (style == 0) y = -20f + (h * 0.22f + 20f) * ease;
        else if (style == 1) scale = 0.5f + 1.5f * ease + (inP < 1f ? 0.25f * (float) Math.sin(inP * Math.PI) : 0f);
        else alpha = fade * ease;
        if (alpha < 0.08f) return;
        MatrixStack ms = ctx.getMatrices();
        ms.push();
        ms.translate(w / 2f, y, 0f);
        ms.scale(scale, scale, 1f);
        Text title = Text.literal("УБИЙСТВО").formatted(Formatting.BOLD);
        int tw = mc.textRenderer.getWidth(title);
        ctx.drawText(mc.textRenderer, title, -tw / 2, 0, ca(accent, alpha), true);
        ms.pop();
        String sub = bannerText + (bannerStreak > 1 ? "  x" + bannerStreak : "");
        ctx.drawCenteredTextWithShadow(mc.textRenderer, sub, w / 2, (int) (y + 8 * scale + 4), ca(0xFFFFFF, alpha));
    }
}
