package com.nova;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Меню мода: вкладки, модули, переключатели, ползунки. Рисуется вручную, без виджетов. */
public class NovaScreen extends Screen {
    private record Hit(NovaConfig.Setting s, int x1, int y1, int x2, int y2, int tx1, int tx2) {}

    private final Screen parent;
    private final long openAt = System.currentTimeMillis();
    private long tabAt = openAt;
    private int tab = 0;
    private float scroll = 0, scrollTarget = 0, maxScroll = 0, indY = -1;

    private NovaConfig.Setting dragging = null, pressed = null, listening = null;
    private Hit dragHit = null;
    private double pressY;
    private boolean scrolling = false;

    private final Map<String, Float> anim = new HashMap<>();
    private final List<Hit> hits = new ArrayList<>();
    private int px, py, pw, ph, cx0, cy0, cw, ch;
    private static final int SW = 100;

    public NovaScreen(Screen parent) {
        super(Text.literal(NovaConfig.NAME));
        this.parent = parent;
    }

    @Override
    protected void init() {
        pw = Math.min(440, width - 8);
        ph = Math.min(270, height - 8);
        px = (width - pw) / 2;
        py = (height - ph) / 2;
        cx0 = px + SW + 10;
        cy0 = py + 32;
        cw = pw - SW - 20;
        ch = ph - 40;
    }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public void close() {
        NovaConfig.save();
        if (client != null) client.setScreen(parent);
    }

    // ---------- цвета и помощники ----------

    private static int ca(int rgb, float a) {
        int al = (int) (Math.max(0f, Math.min(1f, a)) * 255);
        return (Math.max(al, 4) << 24) | (rgb & 0xFFFFFF);
    }

    private static int mixRgb(int c1, int c2, float t) {
        int r = (int) (((c1 >> 16) & 255) * (1 - t) + ((c2 >> 16) & 255) * t);
        int g = (int) (((c1 >> 8) & 255) * (1 - t) + ((c2 >> 8) & 255) * t);
        int b = (int) ((c1 & 255) * (1 - t) + (c2 & 255) * t);
        return (r << 16) | (g << 8) | b;
    }

    /** panel, side, text, muted, row */
    private static int[] pal() {
        switch (NovaConfig.idx("menu.theme")) {
            case 1: return new int[]{0x000000, 0x05060A, 0xEEF1F8, 0x8B93A7, 0x1A1D28};
            case 2: return new int[]{0xF2F3F8, 0xE2E5EE, 0x14161D, 0x5D6577, 0xFFFFFF};
            default: return new int[]{0x101420, 0x0A0D16, 0xEEF1F8, 0x8B93A7, 0x1B2030};
        }
    }

    private void tx(DrawContext c, String s, int x, int y, int col, float a) {
        if (a < 0.06f) return;
        c.drawText(textRenderer, s, x, y, ca(col, a), false);
    }

    private static boolean inside(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx <= x + w && my >= y && my <= y + h;
    }

    private static int rowH(NovaConfig.Setting s) {
        switch (s.type) {
            case MODULE: return 22;
            case HEADER: return 12;
            default: return 18;
        }
    }

    // ---------- отрисовка ----------

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        long now = System.currentTimeMillis();
        float spd = (float) (NovaConfig.num("menu.anim") / 10.0);
        float t = Math.min(1f, (now - openAt) * spd / 300f);
        float e = 1f - (float) Math.pow(1f - t, 3);
        int style = NovaConfig.idx("menu.open");
        int[] pal = pal();
        int accent = NovaConfig.accent();
        float a = e;
        hits.clear();

        ctx.fill(0, 0, width, height, ca(0x000000, 0.5f * e));

        MatrixStack ms = ctx.getMatrices();
        ms.push();
        float sc = style == 0 ? 0.86f + 0.14f * e : 1f;
        float oy = style == 1 ? (1f - e) * 36f : 0f;
        ms.translate(width / 2f, height / 2f + oy, 0f);
        ms.scale(sc, sc, 1f);
        ms.translate(-width / 2f, -height / 2f, 0f);

        // панель и рамка
        ctx.fill(px, py, px + pw, py + ph, ca(pal[0], a * (float) NovaConfig.num("menu.pa") / 100f));
        ctx.fill(px, py, px + SW, py + ph, ca(pal[1], a * 0.9f));
        drawBorder(ctx, accent, a, now);

        drawSidebar(ctx, pal, accent, a, mx, my);

        // заголовок вкладки и кнопка закрытия
        ctx.drawText(textRenderer, Text.literal(NovaConfig.TABS[tab]).formatted(Formatting.BOLD), cx0, py + 12, ca(pal[2], a), false);
        if (tab == 0 && !NovaConfig.riskyAllowed()) {
            tx(ctx, "ESP и Fullbright выключены безопасным режимом", cx0 + 60, py + 12, 0xFF6B6B, a);
        }
        boolean hc = inside(mx, my, px + pw - 22, py + 8, 14, 14);
        ctx.fill(px + pw - 22, py + 8, px + pw - 8, py + 22, ca(hc ? 0xFF4D4D : pal[4], a * (hc ? 0.85f : 0.8f)));
        tx(ctx, "x", px + pw - 17, py + 12, hc ? 0xFFFFFF : pal[2], a);

        drawRows(ctx, pal, accent, a, mx, my, now, e >= 1f);

        ms.pop();
    }

    private void drawBorder(DrawContext ctx, int accent, float a, long now) {
        if (NovaConfig.on("menu.glow")) {
            int g1 = ca(accent, a * 0.22f), g2 = ca(accent, a * 0.09f);
            ctx.fill(px - 1, py - 1, px + pw + 1, py, g1);
            ctx.fill(px - 1, py + ph, px + pw + 1, py + ph + 1, g1);
            ctx.fill(px - 1, py, px, py + ph, g1);
            ctx.fill(px + pw, py, px + pw + 1, py + ph, g1);
            ctx.fill(px - 2, py - 2, px + pw + 2, py - 1, g2);
            ctx.fill(px - 2, py + ph + 1, px + pw + 2, py + ph + 2, g2);
            ctx.fill(px - 2, py - 1, px - 1, py + ph + 1, g2);
            ctx.fill(px + pw + 1, py - 1, px + pw + 2, py + ph + 1, g2);
        }
        int bc = ca(accent, a * 0.85f);
        ctx.fill(px, py, px + pw, py + 1, bc);
        ctx.fill(px, py + ph - 1, px + pw, py + ph, bc);
        ctx.fill(px, py, px + 1, py + ph, bc);
        ctx.fill(px + pw - 1, py, px + pw, py + ph, bc);
        // бегущий блик по верхней кромке
        int sx = px + (int) ((now * 0.12) % (pw + 80)) - 40;
        int x1 = Math.max(px, sx), x2 = Math.min(px + pw, sx + 50);
        if (x2 > x1) ctx.fill(x1, py, x2, py + 1, ca(0xFFFFFF, a * 0.95f));
    }

    private void drawSidebar(DrawContext ctx, int[] pal, int accent, float a, int mx, int my) {
        ctx.drawText(textRenderer, Text.literal(NovaConfig.NAME).formatted(Formatting.BOLD), px + 8, py + 10, ca(accent, a), false);

        float target = py + 34 + tab * 24;
        indY = indY < 0 ? target : indY + (target - indY) * 0.25f;
        int iy = (int) indY;
        ctx.fill(px + 4, iy, px + SW - 4, iy + 22, ca(accent, a * 0.22f));
        ctx.fill(px + 4, iy, px + 6, iy + 22, ca(accent, a));

        for (int i = 0; i < NovaConfig.TABS.length; i++) {
            int y = py + 34 + i * 24;
            boolean hv = inside(mx, my, px + 4, y, SW - 8, 22);
            int col = i == tab ? pal[2] : (hv ? pal[2] : pal[3]);
            tx(ctx, NovaConfig.TABS[i], px + 14 + (hv && i != tab ? 2 : 0), y + 7, col, a);
        }
        String key = NovaClient.menuKey != null ? NovaClient.menuKey.getBoundKeyLocalizedText().getString() : "Insert";
        tx(ctx, key + ": закрыть", px + 8, py + ph - 22, pal[3], a);
        tx(ctx, "Esc: назад", px + 8, py + ph - 12, pal[3], a);
    }

    private void drawRows(DrawContext ctx, int[] pal, int accent, float a, int mx, int my, long now, boolean clip) {
        List<NovaConfig.Setting> rows = new ArrayList<>();
        for (NovaConfig.Setting s : NovaConfig.forTab(NovaConfig.TABS[tab])) {
            if (s.parent == null || NovaConfig.on(s.parent)) rows.add(s);
        }
        float y = cy0 - scroll;
        float total = 0;
        if (clip) ctx.enableScissor(cx0 - 2, cy0, cx0 + cw + 2, cy0 + ch);
        int idx = 0;
        for (NovaConfig.Setting s : rows) {
            int h = rowH(s);
            int gap = s.type == NovaConfig.Type.MODULE ? (idx > 0 ? 5 : 0) : (s.type == NovaConfig.Type.HEADER ? 4 : 2);
            y += gap;
            total += gap;
            float rt = Math.max(0f, Math.min(1f, (now - tabAt - idx * 30L) / 260f));
            float re = 1f - (float) Math.pow(1f - rt, 3);
            int iy = (int) y + (int) ((1f - re) * 10f);
            if (iy + h > cy0 && iy < cy0 + ch) drawRow(ctx, s, iy, pal, accent, a * re, mx, my);
            y += h;
            total += h;
            idx++;
        }
        if (clip) ctx.disableScissor();

        maxScroll = Math.max(0f, total - ch);
        scrollTarget = Math.max(0f, Math.min(maxScroll, scrollTarget));
        scroll += (scrollTarget - scroll) * 0.35f;
        if (maxScroll > 0) {
            int by = cy0 + (int) (scroll / maxScroll * (ch - 24));
            ctx.fill(cx0 + cw + 4, by, cx0 + cw + 6, by + 24, ca(accent, a * 0.7f));
        }
    }

    private void drawRow(DrawContext ctx, NovaConfig.Setting s, int iy, int[] pal, int accent, float a, int mx, int my) {
        int x = cx0;
        switch (s.type) {
            case MODULE: {
                boolean hv = inside(mx, my, x, iy, cw, 22);
                ctx.fill(x, iy, x + cw, iy + 22, ca(pal[4], a * (hv ? 0.95f : 0.78f)));
                if (s.on()) {
                    ctx.fill(x, iy, x + cw, iy + 22, ca(accent, a * 0.10f));
                    ctx.fill(x, iy, x + 2, iy + 22, ca(accent, a));
                }
                tx(ctx, s.label, x + 9, iy + 7, pal[2], a);
                drawSwitch(ctx, s.id, x + cw - 34, iy + 5, s.on(), accent, a);
                hits.add(new Hit(s, x, iy, x + cw, iy + 22, 0, 0));
                break;
            }
            case HEADER:
                tx(ctx, s.label.toUpperCase(), x + 2, iy + 2, pal[3], a);
                break;
            case TOGGLE:
                tx(ctx, s.label, x + 12, iy + 5, pal[2], a);
                drawSwitch(ctx, s.id, x + cw - 34, iy + 3, s.on(), accent, a);
                hits.add(new Hit(s, x, iy, x + cw, iy + 18, 0, 0));
                break;
            case SLIDER: {
                tx(ctx, s.label, x + 12, iy + 5, pal[2], a);
                int tx1 = x + (int) (cw * 0.46f), tx2 = x + cw - 50, ty = iy + 8;
                float cur = anim.getOrDefault(s.id, (float) s.value);
                cur += ((float) s.value - cur) * 0.35f;
                anim.put(s.id, cur);
                float frac = (float) ((cur - s.min) / (s.max - s.min));
                ctx.fill(tx1, ty, tx2, ty + 3, ca(pal[3], a * 0.35f));
                int fx = tx1 + (int) (frac * (tx2 - tx1));
                ctx.fill(tx1, ty, fx, ty + 3, ca(accent, a));
                ctx.fill(fx - 2, iy + 4, fx + 2, iy + 13, ca(0xFFFFFF, a));
                String v = s.text();
                tx(ctx, v, x + cw - 2 - textRenderer.getWidth(v), iy + 5, pal[3], a);
                hits.add(new Hit(s, tx1 - 4, iy, tx2 + 4, iy + 18, tx1, tx2));
                break;
            }
            case CYCLE: {
                tx(ctx, s.label, x + 12, iy + 5, pal[2], a);
                String v = "< " + s.text() + " >";
                int bw = Math.max(70, textRenderer.getWidth(v) + 12);
                boolean hv = inside(mx, my, x + cw - bw, iy, bw, 18);
                ctx.fill(x + cw - bw, iy, x + cw, iy + 18, ca(pal[4], a * (hv ? 0.95f : 0.78f)));
                ctx.fill(x + cw - bw, iy + 17, x + cw, iy + 18, ca(accent, a * 0.6f));
                tx(ctx, v, x + cw - bw + (bw - textRenderer.getWidth(v)) / 2, iy + 5, pal[2], a);
                hits.add(new Hit(s, x + cw - bw, iy, x + cw, iy + 18, 0, 0));
                break;
            }
            case BUTTON: {
                tx(ctx, s.label, x + 12, iy + 5, pal[2], a);
                int bw = 70;
                boolean hv = inside(mx, my, x + cw - bw, iy, bw, 18);
                ctx.fill(x + cw - bw, iy, x + cw, iy + 18, ca(accent, a * (hv ? 0.55f : 0.3f)));
                ctx.fill(x + cw - bw, iy + 17, x + cw, iy + 18, ca(accent, a));
                tx(ctx, "Запуск", x + cw - bw + (bw - textRenderer.getWidth("Запуск")) / 2, iy + 5, pal[2], a);
                hits.add(new Hit(s, x + cw - bw, iy, x + cw, iy + 18, 0, 0));
                break;
            }
            case BIND: {
                tx(ctx, s.label, x + 12, iy + 5, pal[2], a);
                String v = listening == s ? "Нажми клавишу..." : "[ " + s.text() + " ]";
                int bw = Math.max(80, textRenderer.getWidth(v) + 12);
                boolean hv = inside(mx, my, x + cw - bw, iy, bw, 18);
                int fill = listening == s ? ca(accent, a * 0.5f) : ca(pal[4], a * (hv ? 0.95f : 0.78f));
                ctx.fill(x + cw - bw, iy, x + cw, iy + 18, fill);
                ctx.fill(x + cw - bw, iy + 17, x + cw, iy + 18, ca(accent, a * 0.8f));
                tx(ctx, v, x + cw - bw + (bw - textRenderer.getWidth(v)) / 2, iy + 5, pal[2], a);
                hits.add(new Hit(s, x + cw - bw, iy, x + cw, iy + 18, 0, 0));
                break;
            }
            default:
                break;
        }
    }

    private void drawSwitch(DrawContext ctx, String id, int x, int y, boolean on, int accent, float a) {
        float target = on ? 1f : 0f;
        float cur = anim.getOrDefault("sw:" + id, target);
        cur += (target - cur) * 0.3f;
        anim.put("sw:" + id, cur);
        int track = mixRgb(0x555B6E, accent, cur);
        ctx.fill(x, y, x + 26, y + 12, ca(track, a));
        int kx = x + 2 + (int) (cur * 14);
        ctx.fill(kx, y + 2, kx + 10, y + 10, ca(0xFFFFFF, a));
    }

    // ---------- ввод ----------

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (listening != null) {
            listening = null;
            return true;
        }
        if (inside(mx, my, px + pw - 22, py + 8, 14, 14)) {
            close();
            return true;
        }
        for (int i = 0; i < NovaConfig.TABS.length; i++) {
            if (inside(mx, my, px + 4, py + 34 + i * 24, SW - 8, 22)) {
                if (tab != i) {
                    tab = i;
                    tabAt = System.currentTimeMillis();
                    scroll = 0;
                    scrollTarget = 0;
                }
                return true;
            }
        }
        if (inside(mx, my, cx0 - 2, cy0, cw + 4, ch)) {
            for (int i = hits.size() - 1; i >= 0; i--) {
                Hit h = hits.get(i);
                if (inside(mx, my, h.x1(), h.y1(), h.x2() - h.x1(), h.y2() - h.y1())) {
                    if (h.s().type == NovaConfig.Type.SLIDER) {
                        dragging = h.s();
                        dragHit = h;
                        setSlider(mx);
                    } else {
                        pressed = h.s();
                        pressY = my;
                        scrolling = false;
                    }
                    return true;
                }
            }
            pressed = null;
            pressY = my;
            scrolling = true;
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging != null) {
            setSlider(mx);
            return true;
        }
        if (pressed != null && Math.abs(my - pressY) > 4) {
            pressed = null;
            scrolling = true;
        }
        if (scrolling) {
            scrollTarget = Math.max(0f, Math.min(maxScroll, scrollTarget - (float) dy));
            scroll = scrollTarget;
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (dragging != null) {
            dragging = null;
            dragHit = null;
            NovaConfig.save();
            return true;
        }
        if (pressed != null) {
            activate(pressed, button);
            pressed = null;
            return true;
        }
        scrolling = false;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double hAmount, double vAmount) {
        scrollTarget = Math.max(0f, Math.min(maxScroll, scrollTarget - (float) vAmount * 22f));
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (listening != null) {
            if (keyCode != GLFW.GLFW_KEY_ESCAPE) NovaClient.rebind(listening.id, keyCode, scanCode);
            listening = null;
            return true;
        }
        if (NovaClient.menuKey != null && NovaClient.menuKey.matchesKey(keyCode, scanCode)) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    private void activate(NovaConfig.Setting s, int button) {
        if (s.type == NovaConfig.Type.BUTTON) {
            NovaClient.action(s.id);
            return;
        }
        if (s.type == NovaConfig.Type.BIND) {
            listening = s;
            return;
        }
        if (s.type == NovaConfig.Type.MODULE || s.type == NovaConfig.Type.TOGGLE) {
            s.value = s.on() ? 0 : 1;
        } else if (s.type == NovaConfig.Type.CYCLE) {
            int n = (int) s.max + 1;
            int v = (int) s.value + (button == 1 ? -1 : 1);
            s.value = ((v % n) + n) % n;
        }
        NovaConfig.onChanged(s);
        NovaConfig.save();
    }

    private void setSlider(double mx) {
        NovaConfig.Setting s = dragHit.s();
        double frac = Math.max(0, Math.min(1, (mx - dragHit.tx1()) / (double) (dragHit.tx2() - dragHit.tx1())));
        double v = s.min + frac * (s.max - s.min);
        v = Math.round(v / s.step) * s.step;
        s.value = Math.max(s.min, Math.min(s.max, v));
        NovaConfig.onChanged(s);
    }
}
