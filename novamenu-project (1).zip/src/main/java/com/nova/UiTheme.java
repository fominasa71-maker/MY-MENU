package com.nova;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/** Оформление меню Minecraft: фон экранов, титульный экран, логотип. */
public final class UiTheme {
    private UiTheme() {}

    private static float time() {
        return (System.currentTimeMillis() % 1_000_000L) / 1000f * (float) (NovaConfig.num("ui.speed") / 10.0);
    }

    private static int a(int rgb, float al) {
        int v = (int) (Math.max(0f, Math.min(1f, al)) * 255);
        return (Math.max(v, 1) << 24) | (rgb & 0xFFFFFF);
    }

    private static float hash(int i) {
        double x = Math.sin(i * 127.1 + 311.7) * 43758.5453;
        return (float) (x - Math.floor(x));
    }

    public static void drawBackground(DrawContext ctx, int w, int h, boolean inWorld) {
        float t = time();
        float hue = (float) NovaConfig.hue();
        int acc = NovaConfig.accent();
        float base = inWorld ? 0.6f : 1f;
        ctx.fillGradient(0, 0, w, h, a(0x06070F, base), a(0x0E1226, base));
        int style = NovaConfig.idx("ui.bg");
        if (style == 0) {
            for (int k = 0; k < 5; k++) {
                float cy = h * (0.2f + 0.15f * k) + (float) Math.sin(t * 0.7f + k * 1.9f) * h * 0.07f;
                int bh = (int) (h * 0.2f);
                int col = NovaConfig.hsv(hue + k * 22, 0.65f, 1f);
                ctx.fillGradient(0, (int) cy - bh, w, (int) cy, a(col, 0f), a(col, 0.16f * base));
                ctx.fillGradient(0, (int) cy, w, (int) cy + bh, a(col, 0.16f * base), a(col, 0f));
            }
        } else if (style == 1) {
            ctx.fillGradient(0, (int) (h * 0.55f), w, h, a(acc, 0f), a(acc, 0.2f * base));
            for (int i = 0; i < 110; i++) {
                int x = (int) (hash(i) * w), y = (int) (hash(i + 500) * h);
                float tw = (float) (Math.sin(t * 2 + i) + 1) / 2f;
                int size = hash(i + 900) > 0.85f ? 2 : 1;
                ctx.fill(x, y, x + size, y + size, a(0xFFFFFF, (0.25f + 0.65f * tw) * (inWorld ? 0.6f : 1f)));
            }
        } else {
            int horizon = (int) (h * 0.55f);
            ctx.fillGradient(0, horizon - (int) (h * 0.3f), w, horizon, a(acc, 0f), a(acc, 0.18f * base));
            float scroll = (t * 0.6f) % 1f;
            for (int i = 1; i <= 14; i++) {
                float d = (i + scroll) / 14f;
                int y = horizon + (int) (Math.pow(d, 2.2) * (h - horizon));
                ctx.fill(0, y, w, y + 1, a(acc, Math.min(0.55f, 0.1f + d * 0.5f) * base));
            }
            for (int j = -10; j <= 10; j++) {
                for (int y = horizon; y < h; y += 6) {
                    float depth = (y - horizon) / (float) (h - horizon);
                    int x = (int) (w / 2f + j * (w / 14f) * (depth + 0.05f));
                    ctx.fill(x, y, x + 1, y + 6, a(acc, (0.06f + depth * 0.3f) * base));
                }
            }
        }
    }

    /** Название на титульном экране: буквы переливаются цветом акцента. */
    public static void drawTitle(DrawContext ctx, TextRenderer tr, int w) {
        String s = NovaConfig.NAME;
        float t = time();
        float hue = (float) NovaConfig.hue();
        MatrixStack ms = ctx.getMatrices();
        ms.push();
        ms.translate(w / 2f, 26f, 0f);
        ms.scale(3f, 3f, 1f);
        int total = 0;
        for (int i = 0; i < s.length(); i++) total += tr.getWidth(Text.literal(String.valueOf(s.charAt(i))).formatted(Formatting.BOLD));
        int x = -total / 2;
        for (int i = 0; i < s.length(); i++) {
            Text ch = Text.literal(String.valueOf(s.charAt(i))).formatted(Formatting.BOLD);
            int col = NovaConfig.hsv(hue + i * 18 + t * 30f, 0.55f, 1f);
            ctx.drawText(tr, ch, x, 0, col, true);
            x += tr.getWidth(ch);
        }
        ms.pop();
    }
}
