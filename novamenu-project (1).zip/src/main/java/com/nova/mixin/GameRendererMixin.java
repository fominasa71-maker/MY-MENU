package com.nova.mixin;

import com.nova.NovaClient;
import com.nova.NovaConfig;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Зум и отключение тряски камеры при уроне. */
@Mixin(GameRenderer.class)
public class GameRendererMixin {
    @Inject(method = "getFov", at = @At("RETURN"), cancellable = true)
    private void nova$fov(Camera camera, float tickDelta, boolean changingFov, CallbackInfoReturnable<Double> cir) {
        double z = NovaClient.zoomFactor();
        if (z > 1.0001) cir.setReturnValue(cir.getReturnValue() / z);
    }

    @Inject(method = "tiltViewWhenHurt", at = @At("HEAD"), cancellable = true)
    private void nova$hurt(CallbackInfo ci) {
        if (NovaConfig.on("nohurt")) ci.cancel();
    }
}
