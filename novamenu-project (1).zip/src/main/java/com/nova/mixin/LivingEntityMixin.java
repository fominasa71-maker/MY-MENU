package com.nova.mixin;

import com.nova.NovaConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Скорость взмаха руки у локального игрока. */
@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {
    @Inject(method = "getHandSwingDuration", at = @At("RETURN"), cancellable = true)
    private void nova$swing(CallbackInfoReturnable<Integer> cir) {
        if (!NovaConfig.on("swing")) return;
        if ((Object) this != MinecraftClient.getInstance().player) return;
        int d = cir.getReturnValue();
        cir.setReturnValue(Math.max(1, Math.round(d * 100f / (float) NovaConfig.num("swing.spd"))));
    }
}
