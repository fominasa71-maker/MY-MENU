package com.nova.mixin;

import com.nova.NovaConfig;
import com.nova.UiTheme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Титульный экран: свой фон под всеми элементами и своё название сверху. */
@Mixin(TitleScreen.class)
public class TitleScreenMixin {
    @Inject(method = "render", at = @At("HEAD"))
    private void fl1x$bg(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (!NovaConfig.on("ui")) return;
        Screen self = (Screen) (Object) this;
        UiTheme.drawBackground(context, self.width, self.height, false);
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void fl1x$logo(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (!NovaConfig.on("ui") || !NovaConfig.on("ui.logo")) return;
        Screen self = (Screen) (Object) this;
        UiTheme.drawTitle(context, MinecraftClient.getInstance().textRenderer, self.width);
    }
}
