package com.nova.mixin;

import com.nova.NovaConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.PressableWidget;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Свои кнопки Minecraft: тёмная панель с рамкой цвета акцента. */
@Mixin(PressableWidget.class)
public abstract class PressableWidgetMixin {
    @Inject(method = "renderWidget", at = @At("HEAD"), cancellable = true)
    private void fl1x$button(DrawContext ctx, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (!NovaConfig.on("ui") || !NovaConfig.on("ui.btn")) return;
        PressableWidget w = (PressableWidget) (Object) this;
        if (!(w instanceof ButtonWidget)) return;
        boolean hov = w.isHovered();
        boolean act = w.active;
        int x = w.getX(), y = w.getY(), bw = w.getWidth(), bh = w.getHeight();
        int accent = NovaConfig.accent();
        int bg = act ? (hov ? 0xE02A3150 : 0xC0141828) : 0x90101218;
        int line = act ? (hov ? accent : ((accent & 0xFFFFFF) | 0x99000000)) : 0x40FFFFFF;
        ctx.fill(x, y, x + bw, y + bh, bg);
        ctx.fill(x, y, x + bw, y + 1, line);
        ctx.fill(x, y + bh - 1, x + bw, y + bh, line);
        ctx.fill(x, y, x + 1, y + bh, line);
        ctx.fill(x + bw - 1, y, x + bw, y + bh, line);
        if (hov && act) ctx.fill(x, y + bh - 2, x + bw, y + bh, accent);
        ctx.drawCenteredTextWithShadow(MinecraftClient.getInstance().textRenderer, w.getMessage(),
                x + bw / 2, y + (bh - 8) / 2, act ? 0xFFFFFFFF : 0xFFA0A0A0);
        ci.cancel();
    }
}
