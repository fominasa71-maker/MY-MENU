package com.nova.mixin;

import com.nova.NovaConfig;
import net.minecraft.client.gui.RotatingCubeMapRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Отключает вращающуюся панораму на титульном экране: вместо неё рисуется тема мода. */
@Mixin(RotatingCubeMapRenderer.class)
public class RotatingCubeMapRendererMixin {
    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void fl1x$pano(CallbackInfo ci) {
        if (NovaConfig.on("ui")) ci.cancel();
    }
}
