package com.nova.mixin;

import com.nova.NovaConfig;
import net.minecraft.client.gui.LogoDrawer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Прячет ванильный логотип Minecraft, когда включён свой. */
@Mixin(LogoDrawer.class)
public class LogoDrawerMixin {
    @Inject(method = "draw", at = @At("HEAD"), cancellable = true)
    private void fl1x$logo(CallbackInfo ci) {
        if (NovaConfig.on("ui") && NovaConfig.on("ui.logo")) ci.cancel();
    }
}
