package com.nova.mixin;

import com.nova.NovaConfig;
import com.nova.NovaScreen;
import com.nova.UiTheme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Заменяет фон всех экранов Minecraft (настройки, миры, инвентарь, пауза) на тему мода. */
@Mixin(Screen.class)
public class ScreenMixin {
    @Inject(method = "renderBackground", at = @At("HEAD"), cancellable = true)
    private void fl1x$bg(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (!NovaConfig.on("ui")) return;
        Screen self = (Screen) (Object) this;
        if (self instanceof NovaScreen) return;
        UiTheme.drawBackground(context, self.width, self.height, MinecraftClient.getInstance().world != null);
        ci.cancel();
    }
}
