package com.nova;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;

import java.util.Random;

/** Звуки удара и убийства (свои, из мода) и частицы при ударе и убийстве. */
public final class Effects {
    private static final Random R = new Random();

    private Effects() {}

    public static void playSound(String id, float vol, float pitch) {
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.world == null || c.player == null) return;
        SoundEvent ev = SoundEvent.of(Identifier.of("fl1xvisuals", id));
        c.world.playSound(c.player.getX(), c.player.getY(), c.player.getZ(), ev, SoundCategory.PLAYERS, vol, pitch, false);
    }

    public static void hitSound() {
        float pitch = (float) NovaConfig.num("hsound.pitch") / 100f;
        if (NovaConfig.on("hsound.rand")) pitch *= 0.85f + R.nextFloat() * 0.3f;
        playSound(NovaConfig.HIT_SND_ID[NovaConfig.idx("hsound.t")], (float) NovaConfig.num("hsound.vol") / 100f, pitch);
    }

    public static void killSound() {
        playSound(NovaConfig.KILL_SND_ID[NovaConfig.idx("ksound.t")], (float) NovaConfig.num("ksound.vol") / 100f, 1f);
    }

    private static ParticleEffect hitType(int i) {
        switch (i) {
            case 0: return ParticleTypes.CRIT;
            case 1: return ParticleTypes.ENCHANTED_HIT;
            case 2: return ParticleTypes.ELECTRIC_SPARK;
            case 3: return ParticleTypes.HEART;
            case 4: return ParticleTypes.END_ROD;
            case 5: return ParticleTypes.FLAME;
            default: return ParticleTypes.SMOKE;
        }
    }

    private static void burst(ParticleEffect p, int n, double x, double y, double z, double speed, double up) {
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.world == null) return;
        for (int i = 0; i < n; i++) {
            double vx = (R.nextDouble() - 0.5) * 2 * speed;
            double vy = (R.nextDouble() - 0.3) * speed + up;
            double vz = (R.nextDouble() - 0.5) * 2 * speed;
            c.world.addParticle(p, x, y, z, vx, vy, vz);
        }
    }

    public static void hitAnim(double x, double y, double z) {
        burst(hitType(NovaConfig.idx("hanim.t")), (int) NovaConfig.num("hanim.n"), x, y, z, 0.3, 0.05);
    }

    public static void killAnim(double x, double y, double z) {
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.world == null) return;
        int n = (int) NovaConfig.num("kanim.n");
        switch (NovaConfig.idx("kanim.t")) {
            case 0: // салют: два кольца
                for (int i = 0; i < n; i++) {
                    double a = i * Math.PI * 2 / n;
                    c.world.addParticle(ParticleTypes.FIREWORK, x, y, z, Math.cos(a) * 0.28, 0.08, Math.sin(a) * 0.28);
                    c.world.addParticle(ParticleTypes.FIREWORK, x, y, z, Math.cos(a) * 0.12, 0.3 + R.nextDouble() * 0.1, Math.sin(a) * 0.12);
                }
                break;
            case 1:
                burst(ParticleTypes.TOTEM_OF_UNDYING, n, x, y, z, 0.35, 0.25);
                break;
            case 2:
                burst(ParticleTypes.SOUL, n / 2 + 1, x, y, z, 0.08, 0.1);
                burst(ParticleTypes.SOUL_FIRE_FLAME, n / 2 + 1, x, y, z, 0.1, 0.12);
                break;
            case 3:
                c.world.addParticle(ParticleTypes.EXPLOSION, x, y, z, 0, 0, 0);
                burst(ParticleTypes.POOF, n, x, y, z, 0.3, 0.05);
                break;
            case 4:
                burst(ParticleTypes.LARGE_SMOKE, n, x, y, z, 0.15, 0.12);
                break;
            case 5:
                burst(ParticleTypes.HEART, n / 2 + 1, x, y, z, 0.2, 0.15);
                break;
            default:
                burst(ParticleTypes.ELECTRIC_SPARK, n, x, y, z, 0.6, 0.05);
                break;
        }
    }

    public static void onHit(LivingEntity e) {
        if (NovaConfig.on("hsound")) hitSound();
        if (NovaConfig.on("hanim")) hitAnim(e.getX(), e.getBodyY(0.6), e.getZ());
        Hud.hitAt = System.currentTimeMillis();
    }

    public static void onKill(LivingEntity e, int streak) {
        if (NovaConfig.on("ksound")) killSound();
        if (NovaConfig.on("kanim")) killAnim(e.getX(), e.getBodyY(0.5), e.getZ());
        if (NovaConfig.on("kbanner")) Hud.banner(e.getName().getString(), streak);
    }

    /** Кнопки «Проверить» в меню. */
    public static void test(String id) {
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null || c.world == null) {
            Hud.say("Зайди в мир, чтобы проверить");
            return;
        }
        Vec3d p = c.player.getEyePos().add(c.player.getRotationVec(1f).multiply(3));
        switch (id) {
            case "act.hsound": hitSound(); break;
            case "act.ksound": killSound(); break;
            case "act.hanim": hitAnim(p.x, p.y, p.z); break;
            case "act.kanim": killAnim(p.x, p.y, p.z); break;
            case "act.kbanner": Hud.banner("Проверка", 2); break;
            default: break;
        }
    }
}
